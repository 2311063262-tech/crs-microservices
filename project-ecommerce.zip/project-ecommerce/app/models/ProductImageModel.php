<?php

namespace App\Models;

use App\Core\Model;

class ProductImageModel extends Model
{
    protected $table = 'product_images';

    public function getByProductId($productId)
    {
        return $this->where('product_id', '=', $productId);
    }
}

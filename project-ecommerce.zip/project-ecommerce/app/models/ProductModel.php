<?php

namespace App\Models;

use App\Core\Model;

class ProductModel extends Model
{
    protected $table = 'products';

    public function getByCategory($categoryId)
    {
        return $this->where('category_id', '=', $categoryId);
    }

    public function search($keyword)
    {
        $sql = "SELECT * FROM {$this->table} WHERE name LIKE :keyword OR description LIKE :keyword";
        $this->db->query($sql);
        $this->db->bind('keyword', "%{$keyword}%");
        return $this->db->resultSet();
    }

    public function getFeatured()
    {
        return $this->where('is_featured', '=', 1);
    }

    public function getActive()
    {
        return $this->where('is_active', '=', 1);
    }
}

<?php

namespace App\Models;

use App\Core\Model;

class WishlistModel extends Model
{
    protected $table = 'wishlists';

    public function getByUserId($userId)
    {
        return $this->where('user_id', '=', $userId);
    }

    public function isInWishlist($userId, $productId)
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} WHERE user_id = :user_id AND product_id = :product_id";
        $this->db->query($sql);
        $this->db->bind('user_id', $userId);
        $this->db->bind('product_id', $productId);
        $result = $this->db->single();
        return $result['count'] > 0;
    }
}

<?php

namespace App\Models;

use App\Core\Model;

class UserModel extends Model
{
    protected $table = 'users';

    public function findByEmail($email)
    {
        return $this->where('email', '=', $email);
    }

    public function findByUsername($username)
    {
        return $this->where('username', '=', $username);
    }

    public function getAdmins()
    {
        return $this->where('role', '=', 'admin');
    }

    public function getCustomers()
    {
        return $this->where('role', '=', 'customer');
    }
}

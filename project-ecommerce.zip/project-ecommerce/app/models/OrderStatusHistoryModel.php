<?php

namespace App\Models;

use App\Core\Model;

class OrderStatusHistoryModel extends Model
{
    protected $table = 'order_status_history';

    public function getByOrderId($orderId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE order_id = :order_id ORDER BY created_at DESC";
        $this->db->query($sql)->bind('order_id', $orderId);
        return $this->db->resultSet();
    }
}

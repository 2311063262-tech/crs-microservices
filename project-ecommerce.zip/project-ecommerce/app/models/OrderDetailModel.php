<?php

namespace App\Models;

use App\Core\Model;

class OrderDetailModel extends Model
{
    protected $table = 'order_details';

    public function getByOrderId($orderId)
    {
        return $this->where('order_id', '=', $orderId);
    }
}

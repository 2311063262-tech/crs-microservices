<?php

namespace App\Models;

use App\Core\Model;

class VoucherModel extends Model
{
    protected $table = 'vouchers';

    public function findByCode($code)
    {
        return $this->where('code', '=', $code);
    }

    public function getActive()
    {
        $sql = "SELECT * FROM {$this->table} WHERE is_active = 1 AND expire_date >= NOW()";
        $this->db->query($sql);
        return $this->db->resultSet();
    }

    public function isValid($code)
    {
        $results = $this->findByCode($code);

        if (!$results) {
            return false;
        }

        $voucher = $results[0] ?? null;

        if (!$voucher || !$voucher['is_active'] || strtotime($voucher['expire_date']) < time()) {
            return false;
        }

        return $voucher;
    }
}

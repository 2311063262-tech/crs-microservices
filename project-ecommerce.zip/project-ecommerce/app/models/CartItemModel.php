<?php

namespace App\Models;

use App\Core\Model;

class CartItemModel extends Model
{
    protected $table = 'cart_items';

    public function getByCartId($cartId)
    {
        return $this->where('cart_id', '=', $cartId);
    }

    public function getByCartAndProduct($cartId, $productId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE cart_id = :cart_id AND product_id = :product_id LIMIT 1";
        $this->db->query($sql);
        $this->db->bind('cart_id', $cartId);
        $this->db->bind('product_id', $productId);
        return $this->db->single();
    }
}

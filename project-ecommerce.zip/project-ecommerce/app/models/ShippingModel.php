<?php

namespace App\Models;

use App\Core\Model;

class ShippingModel extends Model
{
    protected $table = 'shipping_methods';

    public function getActive()
    {
        return $this->where('is_active', '=', 1);
    }

    public function calculateShippingFee($province, $weight)
    {
        $sql = "SELECT * FROM {$this->table} WHERE province = :province AND is_active = 1";
        $this->db->query($sql)->bind('province', $province);
        $shipping = $this->db->single();

        if (!$shipping) {
            return 0;
        }

        $baseFee = $shipping['base_fee'];
        $additionalFee = $weight > $shipping['weight_limit'] 
            ? ($weight - $shipping['weight_limit']) * $shipping['additional_fee_per_kg']
            : 0;

        return $baseFee + $additionalFee;
    }
}

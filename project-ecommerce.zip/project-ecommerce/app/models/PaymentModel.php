<?php

namespace App\Models;

use App\Core\Model;

class PaymentModel extends Model
{
    protected $table = 'payments';

    public function getByOrderId($orderId)
    {
        return $this->where('order_id', '=', $orderId);
    }

    public function getByStatus($status)
    {
        return $this->where('status', '=', $status);
    }

    public function getPending()
    {
        return $this->where('status', '=', 'pending');
    }

    public function getCompleted()
    {
        return $this->where('status', '=', 'completed');
    }

    public function getFailed()
    {
        return $this->where('status', '=', 'failed');
    }
}

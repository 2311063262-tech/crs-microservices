<?php

namespace App\Models;

use App\Core\Model;

class ProductVariantModel extends Model
{
    protected $table = 'product_variants';

    public function getByProductId($productId)
    {
        return $this->where('product_id', '=', $productId);
    }
}

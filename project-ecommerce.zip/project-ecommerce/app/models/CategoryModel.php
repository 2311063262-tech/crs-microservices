<?php

namespace App\Models;

use App\Core\Model;

class CategoryModel extends Model
{
    protected $table = 'categories';

    public function getActive()
    {
        return $this->where('is_active', '=', 1);
    }
}

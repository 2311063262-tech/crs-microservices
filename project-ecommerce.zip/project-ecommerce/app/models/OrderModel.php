<?php

namespace App\Models;

use App\Core\Model;

class OrderModel extends Model
{
    protected $table = 'orders';

    private function normalizeDateRange($fromDate, $toDate)
    {
        $from = $fromDate ?: date('Y-m-01');
        $to = $toDate ?: date('Y-m-d');

        return [
            $from . ' 00:00:00',
            $to . ' 23:59:59'
        ];
    }

    public function getByUserId($userId)
    {
        return $this->where('user_id', '=', $userId);
    }

    public function getByStatus($status)
    {
        return $this->where('status', '=', $status);
    }

    public function getPending()
    {
        return $this->where('status', '=', 'pending');
    }

    public function getConfirmed()
    {
        return $this->where('status', '=', 'confirmed');
    }

    public function getShipped()
    {
        return $this->where('status', '=', 'shipped');
    }

    public function getCompleted()
    {
        return $this->where('status', '=', 'completed');
    }

    public function getSalesSummary($fromDate, $toDate)
    {
        [$from, $to] = $this->normalizeDateRange($fromDate, $toDate);

        $sql = "SELECT
                    COUNT(*) AS total_orders,
                    SUM(CASE WHEN status != 'cancelled' THEN total_amount ELSE 0 END) AS gross_revenue,
                    SUM(CASE WHEN status != 'cancelled' THEN discount_amount ELSE 0 END) AS total_discount,
                    SUM(CASE WHEN status != 'cancelled' THEN shipping_fee ELSE 0 END) AS total_shipping,
                    AVG(CASE WHEN status != 'cancelled' THEN total_amount ELSE NULL END) AS average_order_value
                FROM {$this->table}
                WHERE created_at BETWEEN :from_date AND :to_date";

        $this->db->query($sql)
            ->bind('from_date', $from)
            ->bind('to_date', $to);

        return $this->db->single() ?: [];
    }

    public function getTopSellingProducts($fromDate, $toDate, $limit = 10)
    {
        [$from, $to] = $this->normalizeDateRange($fromDate, $toDate);

        $sql = "SELECT
                    od.product_id,
                    od.product_name,
                    SUM(od.quantity) AS quantity_sold,
                    SUM(od.subtotal) AS revenue
                FROM order_details od
                INNER JOIN {$this->table} o ON o.id = od.order_id
                WHERE o.created_at BETWEEN :from_date AND :to_date
                  AND o.status != 'cancelled'
                GROUP BY od.product_id, od.product_name
                ORDER BY quantity_sold DESC, revenue DESC
                LIMIT " . (int) $limit;

        $this->db->query($sql)
            ->bind('from_date', $from)
            ->bind('to_date', $to);

        return $this->db->resultSet();
    }

    public function getDailyRevenue($fromDate, $toDate)
    {
        [$from, $to] = $this->normalizeDateRange($fromDate, $toDate);

        $sql = "SELECT
                    DATE(created_at) AS day,
                    COUNT(*) AS orders_count,
                    SUM(CASE WHEN status != 'cancelled' THEN total_amount ELSE 0 END) AS revenue
                FROM {$this->table}
                WHERE created_at BETWEEN :from_date AND :to_date
                GROUP BY DATE(created_at)
                ORDER BY day ASC";

        $this->db->query($sql)
            ->bind('from_date', $from)
            ->bind('to_date', $to);

        return $this->db->resultSet();
    }

    public function getStatusStats($fromDate, $toDate)
    {
        [$from, $to] = $this->normalizeDateRange($fromDate, $toDate);

        $sql = "SELECT status, COUNT(*) AS total
                FROM {$this->table}
                WHERE created_at BETWEEN :from_date AND :to_date
                GROUP BY status
                ORDER BY total DESC";

        $this->db->query($sql)
            ->bind('from_date', $from)
            ->bind('to_date', $to);

        return $this->db->resultSet();
    }
}

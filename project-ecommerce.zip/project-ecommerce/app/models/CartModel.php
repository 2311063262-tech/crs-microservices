<?php

namespace App\Models;

use App\Core\Model;

class CartModel extends Model
{
    protected $table = 'carts';

    public function getByUserId($userId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE user_id = :user_id LIMIT 1";
        $this->db->query($sql)->bind('user_id', $userId);
        return $this->db->single();
    }

    public function getOrCreateCart($userId)
    {
        $cart = $this->getByUserId($userId);

        if (!$cart) {
            $this->insert([
                'user_id' => $userId,
                'total_items' => 0,
                'total_price' => 0,
                'created_at' => date('Y-m-d H:i:s')
            ]);

            $cartId = $this->db->lastInsertId();
            return $this->find($cartId);
        }

        return $cart;
    }
}

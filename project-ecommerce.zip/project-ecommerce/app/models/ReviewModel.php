<?php

namespace App\Models;

use App\Core\Model;

class ReviewModel extends Model
{
    protected $table = 'reviews';

    public function getByProductId($productId)
    {
        $sql = "SELECT * FROM {$this->table} WHERE product_id = :product_id ORDER BY created_at DESC";
        $this->db->query($sql)->bind('product_id', $productId);
        return $this->db->resultSet();
    }

    public function getByUserId($userId)
    {
        return $this->where('user_id', '=', $userId);
    }

    public function getAverageRating($productId)
    {
        $sql = "SELECT AVG(rating) as average FROM {$this->table} WHERE product_id = :product_id";
        $this->db->query($sql)->bind('product_id', $productId);
        $result = $this->db->single();
        return $result['average'] ?? 0;
    }
}

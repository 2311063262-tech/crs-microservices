<?php

namespace App\Models;

use App\Core\Model;

class PaymentLogModel extends Model
{
    protected $table = 'payment_logs';

    public function getByPaymentId($paymentId)
    {
        return $this->where('payment_id', '=', $paymentId);
    }

    public function log($paymentId, $gateway, $action, $requestData, $responseData, $status = 'success')
    {
        return $this->insert([
            'payment_id' => $paymentId,
            'gateway' => $gateway,
            'action' => $action,
            'request_data' => json_encode($requestData),
            'response_data' => json_encode($responseData),
            'status' => $status,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
}

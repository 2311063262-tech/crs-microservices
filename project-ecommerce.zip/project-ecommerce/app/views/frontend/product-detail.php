<?php
// Frontend product detail page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ($product['name'] ?? 'Sản phẩm') . ' - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="product-detail-section">
        <div class="container">
            <?php if (isset($product)): ?>
                <div class="product-detail-wrapper">
                    <!-- Product Images -->
                    <div class="product-images">
                        <div class="main-image">
                            <img src="/project-ecommerce/public/assets/images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
                        </div>
                        <?php if (!empty($product['images'])): ?>
                            <div class="thumbnail-images">
                                <?php foreach ($product['images'] as $image): ?>
                                    <img src="/project-ecommerce/public/assets/images/<?php echo $image['url']; ?>" alt="<?php echo $product['name']; ?>" onclick="changeMainImage(this)">
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Product Info -->
                    <div class="product-info">
                        <h1><?php echo $product['name']; ?></h1>
                        
                        <div class="rating">
                            <div class="stars">
                                <?php 
                                $rating = $product['average_rating'] ?? 0;
                                for ($i = 1; $i <= 5; $i++):
                                    $filled = $i <= $rating ? 'filled' : '';
                                ?>
                                    <span class="star <?php echo $filled; ?>">★</span>
                                <?php endfor; ?>
                            </div>
                            <span class="rating-value"><?php echo round($rating, 1); ?>/5</span>
                        </div>

                        <div class="price">
                            <h2><?php echo formatVND($product['price']); ?></h2>
                        </div>

                        <div class="description">
                            <p><?php echo $product['description']; ?></p>
                        </div>

                        <div class="product-meta">
                            <p><strong>Tồn kho:</strong> <?php echo $product['stock'] > 0 ? 'Còn hàng' : 'Hết hàng'; ?></p>
                            <p><strong>Danh mục:</strong> <?php echo $product['category_id']; ?></p>
                        </div>

                        <?php if (!empty($product['variants'])): ?>
                            <div class="variants">
                                <label><strong>Lựa chọn:</strong></label>
                                <select id="variantSelect">
                                    <option value="">-- Chọn biến thể --</option>
                                    <?php foreach ($product['variants'] as $variant): ?>
                                        <option value="<?php echo $variant['id']; ?>">
                                            <?php echo $variant['attribute_name'] . ': ' . $variant['attribute_value']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>

                        <div class="actions">
                            <input type="number" id="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>">
                            <button class="btn btn-primary btn-lg" onclick="addToCart(<?php echo $product['id']; ?>)">
                                Thêm vào giỏ
                            </button>
                            <button class="btn btn-secondary btn-lg" onclick="addToWishlist(<?php echo $product['id']; ?>)">
                                ♥ Yêu thích
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Reviews Section -->
                <div class="reviews-section">
                    <h3>Đánh giá sản phẩm</h3>
                    
                    <?php if (!empty($product['reviews'])): ?>
                        <div class="reviews-list">
                            <?php foreach ($product['reviews'] as $review): ?>
                                <div class="review-item">
                                    <div class="review-header">
                                        <strong><?php echo $review['user_name'] ?? 'Ẩn danh'; ?></strong>
                                        <div class="review-rating">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <span class="star <?php echo $i <= $review['rating'] ? 'filled' : ''; ?>">★</span>
                                            <?php endfor; ?>
                                        </div>
                                        <small><?php echo formatDate($review['created_at']); ?></small>
                                    </div>
                                    <p><?php echo $review['comment']; ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p>Chưa có đánh giá nào cho sản phẩm này.</p>
                    <?php endif; ?>

                    <!-- Add Review Form -->
                    <?php 
                    $session = new \App\Core\Session();
                    if ($session->isLoggedIn()): 
                    ?>
                        <div class="add-review-form">
                            <h4>Chia sẻ đánh giá của bạn</h4>
                            <form id="reviewForm" class="form">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                
                                <div class="form-group">
                                    <label>Đánh giá:</label>
                                    <div class="star-rating">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <input type="radio" name="rating" value="<?php echo $i; ?>" id="star<?php echo $i; ?>">
                                            <label for="star<?php echo $i; ?>">★</label>
                                        <?php endfor; ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="comment">Nhận xét:</label>
                                    <textarea id="comment" name="comment" rows="4"></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary">Gửi đánh giá</button>
                            </form>
                        </div>
                    <?php else: ?>
                        <p><a href="/project-ecommerce/public/login">Đăng nhập</a> để chia sẻ đánh giá của bạn.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p>Sản phẩm không tìm thấy.</p>
            <?php endif; ?>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
</body>
</html>

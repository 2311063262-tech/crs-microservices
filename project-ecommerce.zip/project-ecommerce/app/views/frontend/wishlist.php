<?php
// Frontend wishlist page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Danh sách yêu thích - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="wishlist-section">
        <div class="container">
            <h2>Danh sách yêu thích</h2>

            <?php if (!empty($products)): ?>
                <div class="products-grid">
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <img src="/project-ecommerce/public/assets/images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
                            <h3><?php echo $product['name']; ?></h3>
                            <p class="price"><?php echo formatVND($product['price']); ?></p>
                            <div class="actions">
                                <a href="/project-ecommerce/public/product/<?php echo $product['id']; ?>" class="btn btn-sm">Chi tiết</a>
                                <button class="btn btn-sm btn-add-cart" onclick="addToCart(<?php echo $product['id']; ?>)">Thêm giỏ</button>
                                <button class="btn btn-sm btn-danger" onclick="removeFromWishlist(<?php echo $product['id']; ?>)">Xóa</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-wishlist">
                    <p>Danh sách yêu thích của bạn trống rỗng.</p>
                    <a href="/project-ecommerce/public/products" class="btn btn-primary">Tiếp tục mua sắm</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
</body>
</html>

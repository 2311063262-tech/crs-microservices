<?php
// Frontend product list page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Sản phẩm - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="products-section">
        <div class="container">
            <h2>Danh sách sản phẩm</h2>

            <!-- Filters -->
            <div class="filters">
                <form method="GET" action="/project-ecommerce/public/products">
                    <select name="category">
                        <option value="">-- Tất cả danh mục --</option>
                        <?php if (!empty($categories)): ?>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo $current_category == $cat['id'] ? 'selected' : ''; ?>>
                                    <?php echo $cat['name']; ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>

                    <input type="text" name="search" placeholder="Tìm kiếm sản phẩm..." value="<?php echo $search_query ?? ''; ?>">
                    <button type="submit" class="btn btn-primary">Tìm kiếm</button>
                </form>
            </div>

            <!-- Products Grid -->
            <div class="products-grid">
                <?php if (!empty($products)): ?>
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <img src="/project-ecommerce/public/assets/images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
                            <h3><?php echo $product['name']; ?></h3>
                            <p class="price"><?php echo formatVND($product['price']); ?></p>
                            <div class="actions">
                                <a href="/project-ecommerce/public/product/<?php echo $product['id']; ?>" class="btn btn-sm">Chi tiết</a>
                                <button class="btn btn-sm btn-add-cart" onclick="addToCart(<?php echo $product['id']; ?>)">Thêm giỏ</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Không tìm thấy sản phẩm nào.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
</body>
</html>

<?php
// Frontend cart page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Giỏ hàng - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="cart-section">
        <div class="container">
            <h2>Giỏ hàng của bạn</h2>

            <?php if (!empty($cart_items)): ?>
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Tổng</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): ?>
                            <tr>
                                <td><?php echo $item['name']; ?></td>
                                <td><?php echo formatVND($item['price']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><?php echo formatVND($item['price'] * $item['quantity']); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-danger" onclick="removeFromCart(<?php echo $item['product_id']; ?>)">Xóa</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="cart-summary">
                    <h3>Tổng cộng: <?php echo formatVND($total); ?></h3>
                    <a href="/project-ecommerce/public/checkout" class="btn btn-primary">Tiến hành thanh toán</a>
                    <a href="/project-ecommerce/public/products" class="btn btn-secondary">Tiếp tục mua sắm</a>
                </div>
            <?php else: ?>
                <div class="empty-cart">
                    <p>Giỏ hàng của bạn trống rỗng.</p>
                    <a href="/project-ecommerce/public/products" class="btn btn-primary">Mua sắm ngay</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
</body>
</html>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Liên hệ - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../layouts/header.php'; ?>

    <section class="hero">
        <div class="container">
            <h2>Liên hệ</h2>
            <p>Đội ngũ hỗ trợ sẵn sàng tư vấn sản phẩm phù hợp cho không gian của bạn.</p>
        </div>
    </section>

    <section class="all-products">
        <div class="container">
            <h2>Thông tin liên hệ</h2>
            <p>Email: info@bedroomdecor.vn</p>
            <p>Hotline: 0123 456 789</p>
            <p>Địa chỉ: 123 Đường ABC, Thành phố XYZ</p>
        </div>
    </section>

    <?php include __DIR__ . '/../layouts/footer.php'; ?>
</body>
</html>

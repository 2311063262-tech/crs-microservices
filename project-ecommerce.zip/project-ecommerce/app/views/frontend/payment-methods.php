<?php
// Frontend payment methods page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Chọn phương thức thanh toán - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="payment-methods-section">
        <div class="container">
            <h2>Chọn phương thức thanh toán</h2>

            <div class="payment-methods">
                <?php if (!empty($payment_methods)): ?>
                    <?php foreach ($payment_methods as $method): ?>
                        <div class="payment-method-card">
                            <div class="method-header">
                                <h3><?php echo $method['name']; ?></h3>
                                <p><?php echo $method['description']; ?></p>
                            </div>
                            <button class="btn btn-primary" onclick="selectPaymentMethod('<?php echo $method['code']; ?>')">
                                Chọn
                            </button>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Bank Transfer Details Modal -->
    <div id="bankModal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" onclick="closeBankModal()">&times;</span>
            <h2>Thông tin chuyển khoản</h2>
            <div id="bankDetails"></div>
        </div>
    </div>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
    <script>
        function selectPaymentMethod(method) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '/project-ecommerce/public/payment/process';
            
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'payment_method';
            input.value = method;
            
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    </script>
</body>
</html>

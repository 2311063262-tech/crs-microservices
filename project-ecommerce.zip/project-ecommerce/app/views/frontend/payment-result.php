<?php
// Frontend payment result page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Kết quả thanh toán - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="payment-result-section">
        <div class="container">
            <?php
            $status = $status ?? 'unknown';
            if ($status === 'success'):
            ?>
                <div class="success-result">
                    <h2>✓ Thanh toán thành công!</h2>
                    <p>Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn sẽ được xử lý trong thời gian sớm nhất.</p>
                    <p>Vui lòng kiểm tra email để nhận thông tin chi tiết đơn hàng.</p>
                    <a href="/project-ecommerce/public/profile" class="btn btn-primary">Xem đơn hàng của tôi</a>
                    <a href="/project-ecommerce/public/" class="btn btn-secondary">Quay về trang chủ</a>
                </div>
            <?php elseif ($status === 'failure'): ?>
                <div class="error-result">
                    <h2>✗ Thanh toán không thành công</h2>
                    <p>Rất tiếc! Thanh toán của bạn không được hoàn tất.</p>
                    <p>Vui lòng kiểm tra lại thông tin thanh toán của bạn và thử lại.</p>
                    <a href="/project-ecommerce/public/checkout" class="btn btn-primary">Quay lại thanh toán</a>
                    <a href="/project-ecommerce/public/" class="btn btn-secondary">Quay về trang chủ</a>
                </div>
            <?php elseif ($status === 'cancel'): ?>
                <div class="warning-result">
                    <h2>⚠ Đơn hàng bị hủy</h2>
                    <p>Thanh toán đã bị hủy. Giỏ hàng của bạn sẽ được bảo tồn.</p>
                    <a href="/project-ecommerce/public/cart" class="btn btn-primary">Quay lại giỏ hàng</a>
                    <a href="/project-ecommerce/public/" class="btn btn-secondary">Quay về trang chủ</a>
                </div>
            <?php else: ?>
                <div class="unknown-result">
                    <h2>Kết quả thanh toán chưa rõ</h2>
                    <p>Vui lòng liên hệ với chúng tôi để biết thêm chi tiết.</p>
                    <a href="/project-ecommerce/public/" class="btn btn-primary">Quay về trang chủ</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
</body>
</html>

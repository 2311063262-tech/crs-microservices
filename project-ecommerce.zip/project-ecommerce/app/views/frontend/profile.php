<?php
// Frontend profile
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Hồ sơ - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="profile-section">
        <div class="container">
            <h2>Hồ sơ cá nhân</h2>

            <div class="profile-wrapper">
                <!-- User Info -->
                <div class="user-info">
                    <h3>Thông tin người dùng</h3>
                    <form id="profileForm" class="form">
                        <div class="form-group">
                            <label for="name">Tên:</label>
                            <input type="text" id="name" name="name" value="<?php echo $user['name'] ?? ''; ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" value="<?php echo $user['email'] ?? ''; ?>" disabled>
                        </div>

                        <div class="form-group">
                            <label for="phone">Số điện thoại:</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo $user['phone'] ?? ''; ?>">
                        </div>

                        <div class="form-group">
                            <label for="address">Địa chỉ:</label>
                            <textarea id="address" name="address"><?php echo $user['address'] ?? ''; ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Cập nhật</button>
                    </form>
                </div>

                <!-- Orders -->
                <div class="user-orders">
                    <h3>Đơn hàng của tôi</h3>
                    <?php if (!empty($orders)): ?>
                        <table class="orders-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tổng tiền</th>
                                    <th>Trạng thái</th>
                                    <th>Ngày tạo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>#<?php echo $order['id']; ?></td>
                                        <td><?php echo formatVND($order['total_amount']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $order['status']; ?>">
                                                <?php echo $order['status']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo formatDate($order['created_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>Bạn chưa có đơn hàng nào.</p>
                        <a href="/project-ecommerce/public/products" class="btn btn-primary">Mua sắm ngay</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
    <script>
        document.getElementById('profileForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);

            fetch('/project-ecommerce/public/profile/update', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Cập nhật thành công!');
                } else {
                    alert('Lỗi: ' + (data.error || 'Cập nhật thất bại'));
                }
            });
        });
    </script>
</body>
</html>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Về chúng tôi - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../layouts/header.php'; ?>

    <section class="hero">
        <div class="container">
            <h2>Về Bedroom Decor</h2>
            <p>Chúng tôi xây dựng không gian phòng ngủ đẹp, tiện nghi và ấm cúng cho mọi gia đình.</p>
        </div>
    </section>

    <section class="all-products">
        <div class="container">
            <h2>Sứ mệnh của chúng tôi</h2>
            <p>Bedroom Decor cung cấp sản phẩm trang trí phòng ngủ với tiêu chí bền đẹp, dễ phối và phù hợp với nhiều phong cách nội thất.</p>
        </div>
    </section>

    <?php include __DIR__ . '/../layouts/footer.php'; ?>
</body>
</html>

<?php
// Frontend home page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Trang chủ - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../layouts/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h2>Chào mừng đến với Bedroom Decor</h2>
            <p>Trang trí phòng ngủ đẹp với những sản phẩm chất lượng cao</p>
            <a href="/project-ecommerce/public/products" class="btn btn-primary">Xem sản phẩm</a>
        </div>
    </section>

    <section class="style-showcase">
        <div class="container">
            <h2>Gợi ý phong cách phòng ngủ</h2>
            <div class="showcase-grid">
                <article class="showcase-card">
                    <img src="/project-ecommerce/public/assets/images/placeholder-room.svg" alt="Phong cách tối giản">
                    <h3>Tối giản hiện đại</h3>
                    <p>Màu trung tính, ánh sáng mềm và bố cục gọn gàng để phòng ngủ luôn thư giãn.</p>
                </article>
                <article class="showcase-card">
                    <img src="/project-ecommerce/public/assets/images/placeholder-room.svg" alt="Phong cách ấm cúng">
                    <h3>Ấm cúng Bắc Âu</h3>
                    <p>Chất liệu gỗ sáng, nệm êm và phụ kiện dệt tạo không gian ngủ ấm áp.</p>
                </article>
                <article class="showcase-card">
                    <img src="/project-ecommerce/public/assets/images/placeholder-room.svg" alt="Phong cách sang trọng">
                    <h3>Sang trọng tinh tế</h3>
                    <p>Nhấn bằng đèn trang trí và ga gối tông đậm để tạo điểm nhấn cao cấp.</p>
                </article>
            </div>
        </div>
    </section>

    <!-- Featured Products -->
    <section class="featured-products">
        <div class="container">
            <h2>Sản phẩm nổi bật</h2>
            <div class="products-grid">
                <?php if (!empty($featured_products)): ?>
                    <?php foreach ($featured_products as $product): ?>
                        <div class="product-card">
                            <?php $image = !empty($product['image']) ? $product['image'] : 'placeholder-room.svg'; ?>
                            <img src="/project-ecommerce/public/assets/images/<?php echo $image; ?>" alt="<?php echo $product['name']; ?>" onerror="this.src='/project-ecommerce/public/assets/images/placeholder-room.svg';">
                            <h3><?php echo $product['name']; ?></h3>
                            <p class="price"><?php echo formatVND($product['price']); ?></p>
                            <p class="description"><?php echo truncate($product['description'], 50); ?></p>
                            <a href="/project-ecommerce/public/product/<?php echo $product['id']; ?>" class="btn btn-sm">Xem chi tiết</a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Chưa có sản phẩm nổi bật trong cơ sở dữ liệu. Hãy thêm dữ liệu để hiển thị danh sách thật.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- All Products -->
    <section class="all-products">
        <div class="container">
            <h2>Tất cả sản phẩm</h2>
            <div class="products-grid">
                <?php if (!empty($all_products)): ?>
                    <?php foreach ($all_products as $product): ?>
                        <div class="product-card">
                            <?php $image = !empty($product['image']) ? $product['image'] : 'placeholder-room.svg'; ?>
                            <img src="/project-ecommerce/public/assets/images/<?php echo $image; ?>" alt="<?php echo $product['name']; ?>" onerror="this.src='/project-ecommerce/public/assets/images/placeholder-room.svg';">
                            <h3><?php echo $product['name']; ?></h3>
                            <p class="price"><?php echo formatVND($product['price']); ?></p>
                            <a href="/project-ecommerce/public/product/<?php echo $product['id']; ?>" class="btn btn-sm">Xem chi tiết</a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Hiện chưa có sản phẩm nào. Bạn có thể thêm sản phẩm trong trang quản trị để hiển thị nội dung thực tế.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php include __DIR__ . '/../layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
</body>
</html>

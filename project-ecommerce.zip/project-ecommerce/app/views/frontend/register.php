<?php
// Frontend register page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Đăng ký - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="auth-section">
        <div class="container">
            <div class="form-wrapper">
                <h2>Đăng ký tài khoản</h2>

                <?php if (isset($errors) && !empty($errors)): ?>
                    <div class="alert alert-error">
                        <?php foreach ($errors as $field => $messages): ?>
                            <?php foreach ($messages as $message): ?>
                                <p><?php echo $message; ?></p>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="/project-ecommerce/public/register" class="form">
                    <div class="form-group">
                        <label for="name">Tên:</label>
                        <input type="text" id="name" name="name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Số điện thoại:</label>
                        <input type="tel" id="phone" name="phone">
                    </div>

                    <div class="form-group">
                        <label for="address">Địa chỉ:</label>
                        <textarea id="address" name="address"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="password">Mật khẩu (tối thiểu 8 ký tự):</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Xác nhận mật khẩu:</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Đăng ký</button>
                </form>

                <p class="redirect">Đã có tài khoản? <a href="/project-ecommerce/public/login">Đăng nhập tại đây</a></p>
            </div>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
</body>
</html>

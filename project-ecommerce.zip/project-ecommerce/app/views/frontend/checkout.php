<?php
// Frontend checkout page
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Thanh toán - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <?php include 'layouts/header.php'; ?>

    <section class="checkout-section">
        <div class="container">
            <h2>Thanh toán</h2>

            <div class="checkout-wrapper">
                <!-- Checkout Form -->
                <div class="checkout-form">
                    <h3>Thông tin giao hàng</h3>
                    <form id="checkoutForm" class="form">
                        <div class="form-group">
                            <label for="full_name">Họ tên:</label>
                            <input type="text" id="full_name" name="full_name" value="<?php echo $user['name'] ?? ''; ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="phone">Số điện thoại:</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo $user['phone'] ?? ''; ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="address">Địa chỉ giao hàng:</label>
                            <textarea id="address" name="address" required><?php echo $user['address'] ?? ''; ?></textarea>
                        </div>

                        <div class="form-group">
                            <label for="payment_method">Phương thức thanh toán:</label>
                            <select id="payment_method" name="payment_method" required>
                                <option value="">-- Chọn phương thức --</option>
                                <option value="cod">Thanh toán khi nhận hàng (COD)</option>
                                <option value="bank_transfer">Chuyển khoản ngân hàng</option>
                                <option value="momo">Ví MoMo</option>
                                <option value="vnpay">VNPay</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="shipping_method">Phương thức vận chuyển:</label>
                            <select id="shipping_method" name="shipping_method">
                                <option value="">-- Chọn vận chuyển --</option>
                                <?php if (!empty($shipping_methods)): ?>
                                    <?php foreach ($shipping_methods as $method): ?>
                                        <option value="<?php echo $method['id']; ?>" data-fee="<?php echo $method['base_fee']; ?>">
                                            <?php echo $method['name']; ?> - <?php echo formatVND($method['base_fee']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="voucher_code">Mã giảm giá (nếu có):</label>
                            <input type="text" id="voucher_code" name="voucher_code" placeholder="Nhập mã giảm giá">
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg">Hoàn tất đơn hàng</button>
                    </form>
                </div>

                <!-- Order Summary -->
                <div class="order-summary">
                    <h3>Tóm tắt đơn hàng</h3>
                    <table class="summary-table">
                        <tbody>
                            <?php if (!empty($cart_items)): ?>
                                <?php foreach ($cart_items as $item): ?>
                                    <tr>
                                        <td><?php echo $item['name']; ?> × <?php echo $item['quantity']; ?></td>
                                        <td><?php echo formatVND($item['price'] * $item['quantity']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            <tr class="total-row">
                                <td>Tổng tiền:</td>
                                <td><?php echo formatVND($total); ?></td>
                            </tr>
                            <tr id="shippingRow" style="display:none;">
                                <td>Vận chuyển:</td>
                                <td id="shippingFee">0 ₫</td>
                            </tr>
                            <tr class="final-total">
                                <td>Thành tiền:</td>
                                <td id="finalTotal"><?php echo formatVND($total); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
    <script>
        document.getElementById('checkoutForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const shippingFee = document.querySelector('#shipping_method').selectedOptions[0].dataset.fee || 0;
            formData.append('shipping_fee', shippingFee);

            fetch('/project-ecommerce/public/checkout', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = data.redirect_url;
                } else {
                    alert('Lỗi: ' + (data.error || 'Không thể tạo đơn hàng'));
                }
            });
        });

        document.getElementById('shipping_method').addEventListener('change', function() {
            const fee = this.selectedOptions[0].dataset.fee || 0;
            const baseTotal = <?php echo $total; ?>;
            const total = baseTotal + parseInt(fee);
            
            if (fee > 0) {
                document.getElementById('shippingRow').style.display = 'table-row';
                document.getElementById('shippingFee').textContent = formatVND(fee);
            }
            document.getElementById('finalTotal').textContent = formatVND(total);
        });
    </script>
</body>
</html>

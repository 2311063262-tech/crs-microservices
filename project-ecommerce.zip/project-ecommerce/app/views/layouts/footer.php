<?php
// Frontend layout footer
?>

<footer class="site-footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h4>Về chúng tôi</h4>
                <p>Bedroom Decor là nơi bạn tìm được những sản phẩm trang trí phòng ngủ đẹp và chất lượng cao.</p>
            </div>
            <div class="footer-section">
                <h4>Liên kết nhanh</h4>
                <ul>
                    <li><a href="/project-ecommerce/public/">Trang chủ</a></li>
                    <li><a href="/project-ecommerce/public/products">Sản phẩm</a></li>
                    <li><a href="/project-ecommerce/public/about">Về chúng tôi</a></li>
                    <li><a href="/project-ecommerce/public/contact">Liên hệ</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Hỗ trợ khách hàng</h4>
                <ul>
                    <li><a href="#">Chính sách giao hàng</a></li>
                    <li><a href="#">Chính sách đổi trả</a></li>
                    <li><a href="#">Câu hỏi thường gặp</a></li>
                    <li><a href="#">Liên hệ chúng tôi</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Liên hệ</h4>
                <p>Email: info@bedroomdecor.vn</p>
                <p>Hotline: 0123 456 789</p>
                <p>Địa chỉ: 123 Đường ABC, Thành phố XYZ</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Bedroom Decor eCommerce. All rights reserved.</p>
        </div>
    </div>
</footer>

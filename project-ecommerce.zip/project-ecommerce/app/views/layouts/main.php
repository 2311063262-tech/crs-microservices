<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Bedroom Decor eCommerce'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="logo">
                <h1>🏠 Bedroom Decor</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="/project-ecommerce/public/">Trang chủ</a></li>
                <li><a href="/project-ecommerce/public/products">Sản phẩm</a></li>
                <li><a href="/project-ecommerce/public/cart">Giỏ hàng</a></li>
                <li><a href="/project-ecommerce/public/wishlist">Yêu thích</a></li>
                <?php if (isset($user) && $user): ?>
                    <li><a href="/project-ecommerce/public/profile">Tài khoản</a></li>
                    <li><a href="/project-ecommerce/public/logout">Đăng xuất</a></li>
                <?php else: ?>
                    <li><a href="/project-ecommerce/public/login">Đăng nhập</a></li>
                    <li><a href="/project-ecommerce/public/register">Đăng ký</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <div class="container">
            <?php if (isset($error_message)): ?>
                <div class="alert alert-error"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <?php if (isset($success_message)): ?>
                <div class="alert alert-success"><?php echo $success_message; ?></div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Bedroom Decor eCommerce. All rights reserved.</p>
        </div>
    </footer>

    <script src="/project-ecommerce/public/assets/js/main.js"></script>
</body>
</html>

<?php
// Frontend layout header
?>

<header class="site-header">
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="/project-ecommerce/public/">
                🏠 Bedroom Decor
            </a>
            <button class="navbar-toggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a class="nav-link" href="/project-ecommerce/public/">Trang chủ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/project-ecommerce/public/products">Sản phẩm</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/project-ecommerce/public/cart">Giỏ hàng</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/project-ecommerce/public/wishlist">Yêu thích</a>
                </li>
                <?php 
                $session = new \App\Core\Session();
                $user = $session->getUser();
                if ($user): 
                ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#"><?php echo $user['name']; ?></a>
                        <ul class="dropdown-menu">
                            <li><a href="/project-ecommerce/public/profile">Hồ sơ của tôi</a></li>
                            <?php if ($user['role'] === 'admin'): ?>
                                <li><a href="/project-ecommerce/public/admin">Quản trị</a></li>
                            <?php endif; ?>
                            <li><a href="/project-ecommerce/public/logout">Đăng xuất</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/project-ecommerce/public/login">Đăng nhập</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/project-ecommerce/public/register">Đăng ký</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</header>

<?php
// Admin dashboard
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Admin Dashboard - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">Admin Panel</div>
            <nav class="sidebar-menu">
                <a href="/project-ecommerce/public/admin" class="menu-item active">Trang chủ</a>
                <a href="/project-ecommerce/public/admin/products" class="menu-item">Sản phẩm</a>
                <a href="/project-ecommerce/public/admin/orders" class="menu-item">Đơn hàng</a>
                <a href="/project-ecommerce/public/admin/payments" class="menu-item">Thanh toán</a>
                <a href="/project-ecommerce/public/admin/reports" class="menu-item">Thống kê</a>
                <a href="/project-ecommerce/public/admin/vouchers" class="menu-item">Mã giảm giá</a>
                <a href="/project-ecommerce/public/admin/reviews" class="menu-item">Đánh giá</a>
                <a href="/project-ecommerce/public/admin/customers" class="menu-item">Khách hàng</a>
                <a href="/project-ecommerce/public/logout" class="menu-item">Đăng xuất</a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="admin-content">
            <header class="admin-header">
                <h1>Bảng điều khiển Admin</h1>
            </header>

            <!-- Dashboard Stats -->
            <section class="dashboard-stats">
                <div class="stat-card">
                    <h3>Tổng sản phẩm</h3>
                    <p class="stat-value"><?php echo $total_products; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Tổng đơn hàng</h3>
                    <p class="stat-value"><?php echo $total_orders; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Khách hàng</h3>
                    <p class="stat-value"><?php echo $total_customers; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Doanh thu</h3>
                    <p class="stat-value"><?php echo formatVND($total_revenue); ?></p>
                </div>
            </section>

            <!-- Recent Orders -->
            <section class="recent-orders">
                <h2>Đơn hàng gần đây</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Khách hàng</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Ngày tạo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recent_orders)): ?>
                            <?php foreach ($recent_orders as $order): ?>
                                <tr>
                                    <td>#<?php echo $order['id']; ?></td>
                                    <td><?php echo $order['full_name']; ?></td>
                                    <td><?php echo formatVND($order['total_amount']); ?></td>
                                    <td><span class="badge badge-<?php echo $order['status']; ?>"><?php echo $order['status']; ?></span></td>
                                    <td><?php echo formatDate($order['created_at']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <script src="/project-ecommerce/public/assets/js/admin.js"></script>
</body>
</html>

<?php
// Admin products
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Quản lý sản phẩm - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'sidebar.php'; ?>

        <main class="admin-content">
            <header class="admin-header">
                <h1>Quản lý sản phẩm</h1>
            </header>

            <section class="admin-section">
                <div class="section-header">
                    <h2>Danh sách sản phẩm</h2>
                    <button class="btn btn-primary" onclick="openAddProductModal()">+ Thêm sản phẩm</button>
                </div>

                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tên sản phẩm</th>
                            <th>Danh mục</th>
                            <th>Giá</th>
                            <th>Tồn kho</th>
                            <th>Trạng thái</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($products)): ?>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td>#<?php echo $product['id']; ?></td>
                                    <td><?php echo $product['name']; ?></td>
                                    <td><?php echo $product['category_id']; ?></td>
                                    <td><?php echo formatVND($product['price']); ?></td>
                                    <td><?php echo $product['stock']; ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $product['is_active'] ? 'confirmed' : 'cancelled'; ?>">
                                            <?php echo $product['is_active'] ? 'Hoạt động' : 'Ẩn'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm" onclick="editProduct(<?php echo $product['id']; ?>)">Sửa</button>
                                        <button class="btn btn-sm btn-danger" onclick="deleteProduct(<?php echo $product['id']; ?>)">Xóa</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center">Không có sản phẩm nào</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <!-- Modal Add/Edit Product -->
    <div id="productModal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close" onclick="closeProductModal()">&times;</span>
            <h2>Thêm sản phẩm</h2>
            <form id="productForm" class="form">
                <input type="hidden" id="productId" name="product_id">
                
                <div class="form-group">
                    <label for="category_id">Danh mục:</label>
                    <select id="category_id" name="category_id" required></select>
                </div>

                <div class="form-group">
                    <label for="name">Tên sản phẩm:</label>
                    <input type="text" id="name" name="name" required>
                </div>

                <div class="form-group">
                    <label for="description">Mô tả:</label>
                    <textarea id="description" name="description" rows="4"></textarea>
                </div>

                <div class="form-group">
                    <label for="price">Giá:</label>
                    <input type="number" id="price" name="price" step="0.01" required>
                </div>

                <div class="form-group">
                    <label for="stock">Tồn kho:</label>
                    <input type="number" id="stock" name="stock" required>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" id="is_featured" name="is_featured">
                        Sản phẩm nổi bật
                    </label>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" id="is_active" name="is_active" checked>
                        Hoạt động
                    </label>
                </div>

                <button type="submit" class="btn btn-primary">Lưu</button>
            </form>
        </div>
    </div>

    <script src="/project-ecommerce/public/assets/js/admin.js"></script>
</body>
</html>

<?php
// Admin customers
?>

<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $page_title ?? 'Quản lý khách hàng - Bedroom Decor'; ?></title>
	<link rel="stylesheet" href="/project-ecommerce/public/assets/css/admin.css">
</head>
<body>
	<div class="admin-wrapper">
		<?php include 'sidebar.php'; ?>

		<main class="admin-content">
			<header class="admin-header">
				<h1>Quản lý khách hàng</h1>
			</header>

			<section class="admin-section">
				<table class="table">
					<thead>
						<tr>
							<th>ID</th>
							<th>Họ tên</th>
							<th>Email</th>
							<th>Số điện thoại</th>
							<th>Trạng thái</th>
							<th>Ngày tạo</th>
							<th>Hành động</th>
						</tr>
					</thead>
					<tbody>
						<?php if (!empty($customers)): ?>
							<?php foreach ($customers as $customer): ?>
								<tr>
									<td>#<?php echo $customer['id']; ?></td>
									<td><?php echo htmlspecialchars($customer['name']); ?></td>
									<td><?php echo htmlspecialchars($customer['email']); ?></td>
									<td><?php echo htmlspecialchars($customer['phone'] ?? ''); ?></td>
									<td>
										<?php $isActive = (int) ($customer['is_active'] ?? 1); ?>
										<span class="badge <?php echo $isActive ? 'badge-completed' : 'badge-cancelled'; ?>">
											<?php echo $isActive ? 'Đang hoạt động' : 'Đã khóa'; ?>
										</span>
									</td>
									<td><?php echo formatDate($customer['created_at']); ?></td>
									<td>
										<button
											type="button"
											class="btn btn-sm <?php echo $isActive ? 'btn-danger' : 'btn-success'; ?>"
											onclick="toggleCustomerStatus(<?php echo (int) $customer['id']; ?>, <?php echo $isActive ? 0 : 1; ?>)"
										>
											<?php echo $isActive ? 'Khóa' : 'Mở khóa'; ?>
										</button>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php else: ?>
							<tr>
								<td colspan="7" class="text-center">Không có khách hàng nào</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</section>
		</main>
	</div>

	<script src="/project-ecommerce/public/assets/js/admin.js"></script>
</body>
</html>

<?php
// Admin sidebar
?>

<aside class="sidebar">
    <div class="logo">
        <h3>Admin Panel</h3>
        <p>Bedroom Decor</p>
    </div>
    <nav class="sidebar-menu">
        <a href="/project-ecommerce/public/admin" class="menu-item <?php echo $page_title === 'Admin Dashboard - Bedroom Decor' ? 'active' : ''; ?>">
            📊 Trang chủ
        </a>
        <a href="/project-ecommerce/public/admin/products" class="menu-item <?php echo strpos($page_title ?? '', 'sản phẩm') !== false ? 'active' : ''; ?>">
            📦 Quản lý sản phẩm
        </a>
        <a href="/project-ecommerce/public/admin/orders" class="menu-item <?php echo strpos($page_title ?? '', 'đơn hàng') !== false ? 'active' : ''; ?>">
            📋 Quản lý đơn hàng
        </a>
        <a href="/project-ecommerce/public/admin/payments" class="menu-item <?php echo strpos($page_title ?? '', 'thanh toán') !== false ? 'active' : ''; ?>">
            💳 Thanh toán
        </a>
        <a href="/project-ecommerce/public/admin/reports" class="menu-item <?php echo strpos(mb_strtolower($page_title ?? '', 'UTF-8'), 'thống kê') !== false ? 'active' : ''; ?>">
            📈 Thống kê doanh số
        </a>
        <a href="/project-ecommerce/public/admin/vouchers" class="menu-item <?php echo strpos($page_title ?? '', 'mã giảm') !== false ? 'active' : ''; ?>">
            🎟️ Mã giảm giá
        </a>
        <a href="/project-ecommerce/public/admin/reviews" class="menu-item <?php echo strpos($page_title ?? '', 'đánh giá') !== false ? 'active' : ''; ?>">
            ⭐ Đánh giá
        </a>
        <a href="/project-ecommerce/public/admin/customers" class="menu-item <?php echo strpos($page_title ?? '', 'khách hàng') !== false ? 'active' : ''; ?>">
            👥 Khách hàng
        </a>
        <hr>
        <a href="/project-ecommerce/public/" class="menu-item">
            🏠 Trang chủ website
        </a>
        <a href="/project-ecommerce/public/logout" class="menu-item">
            🚪 Đăng xuất
        </a>
    </nav>
</aside>

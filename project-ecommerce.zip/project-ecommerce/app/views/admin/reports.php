<?php
// Admin sales reports
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Thống kê doanh số - Bedroom Decor'; ?></title>
    <link rel="stylesheet" href="/project-ecommerce/public/assets/css/admin.css">
</head>
<body>
    <div class="admin-wrapper">
        <?php include 'sidebar.php'; ?>

        <main class="admin-content">
            <header class="admin-header">
                <h1>Thống kê doanh số</h1>
            </header>

            <section class="admin-section">
                <form method="GET" action="/project-ecommerce/public/admin/reports" class="report-filter-form">
                    <div class="form-group-inline">
                        <label for="from_date">Từ ngày</label>
                        <input type="date" id="from_date" name="from_date" value="<?php echo htmlspecialchars($from_date); ?>">
                    </div>
                    <div class="form-group-inline">
                        <label for="to_date">Đến ngày</label>
                        <input type="date" id="to_date" name="to_date" value="<?php echo htmlspecialchars($to_date); ?>">
                    </div>
                    <button type="submit" class="btn btn-sm btn-success">Xem báo cáo</button>
                </form>
            </section>

            <section class="dashboard-stats">
                <div class="stat-card">
                    <h3>Tổng đơn hàng</h3>
                    <p class="stat-value"><?php echo (int) ($summary['total_orders'] ?? 0); ?></p>
                </div>
                <div class="stat-card">
                    <h3>Doanh thu gộp</h3>
                    <p class="stat-value"><?php echo formatVND((float) ($summary['gross_revenue'] ?? 0)); ?></p>
                </div>
                <div class="stat-card">
                    <h3>Tổng giảm giá</h3>
                    <p class="stat-value"><?php echo formatVND((float) ($summary['total_discount'] ?? 0)); ?></p>
                </div>
                <div class="stat-card">
                    <h3>Giá trị đơn TB</h3>
                    <p class="stat-value"><?php echo formatVND((float) ($summary['average_order_value'] ?? 0)); ?></p>
                </div>
            </section>

            <section class="admin-section">
                <h2>Sản phẩm bán chạy</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Sản phẩm</th>
                            <th>Số lượng đã bán</th>
                            <th>Doanh thu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($top_products)): ?>
                            <?php foreach ($top_products as $index => $item): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><?php echo (int) $item['quantity_sold']; ?></td>
                                    <td><?php echo formatVND((float) $item['revenue']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">Chưa có dữ liệu bán hàng trong khoảng thời gian này</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>

            <section class="admin-section">
                <h2>Doanh thu theo ngày</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Ngày</th>
                            <th>Số đơn</th>
                            <th>Doanh thu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($daily_revenue)): ?>
                            <?php foreach ($daily_revenue as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['day']); ?></td>
                                    <td><?php echo (int) $row['orders_count']; ?></td>
                                    <td><?php echo formatVND((float) $row['revenue']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center">Không có dữ liệu doanh thu theo ngày</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>

            <section class="admin-section">
                <h2>Phân bố trạng thái đơn hàng</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Trạng thái</th>
                            <th>Số lượng</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($status_stats)): ?>
                            <?php foreach ($status_stats as $status): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($status['status']); ?></td>
                                    <td><?php echo (int) $status['total']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2" class="text-center">Không có dữ liệu trạng thái</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <script src="/project-ecommerce/public/assets/js/admin.js"></script>
</body>
</html>

<?php
// Admin payments, vouchers, reviews, customers - simplified stub views
?>

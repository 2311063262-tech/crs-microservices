<?php

namespace App\Services\Payment;

class MomoPayment implements PaymentInterface
{
    private $config;

    public function __construct()
    {
        $this->config = require __DIR__ . '/../../../config/payment.php';
        $this->config = $this->config['momo'];
    }

    public function process($data)
    {
        $orderId = $data['order_id'];
        $amount = $data['amount'];
        $orderInfo = $data['order_info'] ?? 'Payment for order #' . $orderId;

        $endpoint = $this->config['api_url'];
        $partnerCode = $this->config['partner_code'];
        $accessKey = $this->config['access_key'];
        $secretKey = $this->config['secret_key'];
        $requestId = 'ORDER' . $orderId . time();
        $requestType = 'captureMoMoWallet';
        $ipnUrl = $this->config['ipn_url'];
        $redirectUrl = $this->config['redirect_url'];
        $extraData = '';

        $rawHash = "accessKey={$accessKey}&amount={$amount}&extraData={$extraData}&ipnUrl={$ipnUrl}&orderId={$orderId}&orderInfo={$orderInfo}&partnerCode={$partnerCode}&redirectUrl={$redirectUrl}&requestId={$requestId}&requestType={$requestType}";

        $signature = hash_hmac('sha256', $rawHash, $secretKey);

        $postData = json_encode([
            'partnerCode' => $partnerCode,
            'requestId' => $requestId,
            'amount' => $amount,
            'orderId' => $orderId,
            'orderInfo' => $orderInfo,
            'redirectUrl' => $redirectUrl,
            'ipnUrl' => $ipnUrl,
            'lang' => 'vi',
            'requestType' => $requestType,
            'signature' => $signature,
            'extraData' => $extraData
        ]);

        $ch = curl_init($endpoint);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $response = curl_exec($ch);
        curl_close($ch);

        $responseData = json_decode($response, true);

        if ($responseData['resultCode'] == 0) {
            return [
                'success' => true,
                'redirect_url' => $responseData['payUrl'],
                'message' => 'Redirecting to MoMo payment...'
            ];
        }

        return [
            'success' => false,
            'message' => $responseData['message'] ?? 'Payment processing error',
            'error_code' => $responseData['resultCode']
        ];
    }

    public function verifyCallback($data)
    {
        $signature = $data['signature'] ?? '';
        $secretKey = $this->config['secret_key'];

        unset($data['signature']);

        $rawHash = '';
        foreach ($data as $key => $value) {
            if (!in_array($key, ['signature'])) {
                $rawHash .= $key . '=' . $value . '&';
            }
        }
        $rawHash = rtrim($rawHash, '&');

        $calculatedSignature = hash_hmac('sha256', $rawHash, $secretKey);

        return $calculatedSignature === $signature && $data['resultCode'] == 0;
    }

    public function getName()
    {
        return 'MoMo Wallet';
    }

    public function getDescription()
    {
        return 'Pay using MoMo wallet (Vietnamese payment app)';
    }

    public function getCode()
    {
        return 'momo';
    }
}

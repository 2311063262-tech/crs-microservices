<?php

namespace App\Services\Payment;

class VnpayPayment implements PaymentInterface
{
    private $config;

    public function __construct()
    {
        $this->config = require __DIR__ . '/../../../config/payment.php';
        $this->config = $this->config['vnpay'];
    }

    public function process($data)
    {
        $orderId = $data['order_id'];
        $amount = intval($data['amount'] * 100); // VNPay requires amount in cents
        $merchantId = $this->config['merchant_id'];
        $hashSecret = $this->config['hash_secret'];
        $paymentUrl = $this->config['payment_url'];
        $returnUrl = $this->config['return_url'];
        $ipnUrl = $this->config['ipn_url'];

        $inputData = [
            'vnp_Version' => '2.1.0',
            'vnp_TmnCode' => $merchantId,
            'vnp_Amount' => $amount,
            'vnp_Command' => 'pay',
            'vnp_CreateDate' => date('YmdHis'),
            'vnp_CurrCode' => 'VND',
            'vnp_IpAddr' => $this->getClientIp(),
            'vnp_Locale' => 'vi',
            'vnp_OrderInfo' => 'Payment for order #' . $orderId,
            'vnp_OrderType' => 'billpayment',
            'vnp_ReturnUrl' => $returnUrl,
            'vnp_TxnRef' => $orderId . time(),
        ];

        ksort($inputData);

        $query = '';
        foreach ($inputData as $key => $value) {
            $query .= urlencode($key) . '=' . urlencode($value) . '&';
        }
        $query = rtrim($query, '&');

        $vnpHashSecret = $hashSecret;
        $vnpSecureHash = hash_hmac('sha512', $query, $vnpHashSecret);

        $vnpPaymentUrl = $paymentUrl . '?' . $query . '&vnp_SecureHash=' . $vnpSecureHash;

        return [
            'success' => true,
            'redirect_url' => $vnpPaymentUrl,
            'message' => 'Redirecting to VNPay...'
        ];
    }

    public function verifyCallback($data)
    {
        $vnpSecureHash = $data['vnp_SecureHash'] ?? '';
        $hashSecret = $this->config['hash_secret'];

        unset($data['vnp_SecureHash']);
        unset($data['vnp_SecureHashType']);

        ksort($data);

        $query = '';
        foreach ($data as $key => $value) {
            $query .= urlencode($key) . '=' . urlencode($value) . '&';
        }
        $query = rtrim($query, '&');

        $calculatedHash = hash_hmac('sha512', $query, $hashSecret);

        return $calculatedHash === $vnpSecureHash && $data['vnp_ResponseCode'] == '00';
    }

    public function getName()
    {
        return 'VNPay Payment';
    }

    public function getDescription()
    {
        return 'Pay with VNPay (ATM card, Visa, Mastercard)';
    }

    public function getCode()
    {
        return 'vnpay';
    }

    private function getClientIp()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }
}

<?php

namespace App\Services\Payment;

class BankTransferPayment implements PaymentInterface
{
    private $config;

    public function __construct()
    {
        $this->config = require __DIR__ . '/../../../config/payment.php';
    }

    public function process($data)
    {
        // Lưu thông tin chuyển khoản vào database
        // Và hiển thị chi tiết tài khoản ngân hàng cho khách hàng
        
        return [
            'success' => true,
            'message' => 'Please transfer the exact amount to the bank account below',
            'redirect_url' => '/project-ecommerce/public/payment-result?status=pending',
            'bank_accounts' => $this->config['bank_transfer']['bank_accounts']
        ];
    }

    public function verifyCallback($data)
    {
        // Chuyển khoản ngân hàng cần xác minh thủ công
        // Hoặc tích hợp với API ngân hàng (nếu có)
        return true;
    }

    public function getName()
    {
        return 'Bank Transfer';
    }

    public function getDescription()
    {
        return 'Direct bank transfer. Bank details will be provided after ordering.';
    }

    public function getCode()
    {
        return 'bank_transfer';
    }

    public function getBankAccounts()
    {
        return $this->config['bank_transfer']['bank_accounts'];
    }
}

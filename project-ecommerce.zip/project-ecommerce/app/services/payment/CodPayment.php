<?php

namespace App\Services\Payment;

class CodPayment implements PaymentInterface
{
    public function process($data)
    {
        // Thanh toán khi nhận hàng - không cần xử lý gì đặc biệt
        // Chỉ cần lưu vào database và trả về thành công
        return [
            'success' => true,
            'message' => 'Order confirmed. Please wait for confirmation.',
            'redirect_url' => '/project-ecommerce/public/payment-result?status=success'
        ];
    }

    public function verifyCallback($data)
    {
        // COD không có callback từ bên thứ 3
        return true;
    }

    public function getName()
    {
        return 'Cash on Delivery (COD)';
    }

    public function getDescription()
    {
        return 'Pay when the product arrives at your address';
    }

    public function getCode()
    {
        return 'cod';
    }
}

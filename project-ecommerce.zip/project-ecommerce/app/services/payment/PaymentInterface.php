<?php

namespace App\Services\Payment;

interface PaymentInterface
{
    /**
     * Xử lý thanh toán
     * @param array $data Dữ liệu giao dịch
     * @return array Kết quả giao dịch ['success' => true/false, 'redirect_url' => '...', 'message' => '...']
     */
    public function process($data);

    /**
     * Xác thực callback từ gateway
     * @param array $data Dữ liệu callback
     * @return bool
     */
    public function verifyCallback($data);

    /**
     * Lấy tên phương thức thanh toán
     * @return string
     */
    public function getName();

    /**
     * Lấy mô tả phương thức
     * @return string
     */
    public function getDescription();
}

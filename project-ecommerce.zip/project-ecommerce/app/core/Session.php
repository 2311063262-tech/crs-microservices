<?php

namespace App\Core;

class Session
{
    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function set($key, $value)
    {
        $_SESSION[$key] = $value;
        return $this;
    }

    public function get($key, $default = null)
    {
        return $_SESSION[$key] ?? $default;
    }

    public function has($key)
    {
        return isset($_SESSION[$key]);
    }

    public function delete($key)
    {
        if (isset($_SESSION[$key])) {
            unset($_SESSION[$key]);
        }
        return $this;
    }

    public function destroy()
    {
        session_destroy();
        $_SESSION = [];
        return $this;
    }

    public function flash($key, $message = null)
    {
        if (!is_null($message)) {
            $_SESSION['flash'][$key] = $message;
        } else {
            $message = $_SESSION['flash'][$key] ?? null;
            unset($_SESSION['flash'][$key]);
            return $message;
        }
    }

    public function getUser()
    {
        return $this->get('user', null);
    }

    public function setUser($user)
    {
        return $this->set('user', $user);
    }

    public function isLoggedIn()
    {
        return $this->has('user');
    }

    public function logout()
    {
        $this->delete('user');
        $this->delete('cart');
        return $this;
    }

    public function getCart()
    {
        return $this->get('cart', []);
    }

    public function setCart($cart)
    {
        return $this->set('cart', $cart);
    }

    public function clearCart()
    {
        return $this->delete('cart');
    }

    public function all()
    {
        return $_SESSION;
    }
}

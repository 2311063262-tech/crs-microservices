<?php

namespace App\Core;

class Database
{
    private $host;
    private $port;
    private $database;
    private $username;
    private $password;
    private $charset;
    private $connection;
    private $statement;

    public function __construct()
    {
        $config = require __DIR__ . '/../../config/database.php';
        
        $this->host = $config['host'];
        $this->port = $config['port'];
        $this->database = $config['database'];
        $this->username = $config['username'];
        $this->password = $config['password'];
        $this->charset = $config['charset'];
        
        $this->connect();
    }

    public function connect()
    {
        $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->database};charset={$this->charset}";
        
        try {
            $this->connection = new \PDO($dsn, $this->username, $this->password, [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                \PDO::ATTR_PERSISTENT => false,
            ]);
        } catch (\PDOException $e) {
            die("Database Connection Error: " . $e->getMessage());
        }
    }

    public function query($sql)
    {
        $this->statement = $this->connection->prepare($sql);
        return $this;
    }

    public function bind($param, $value, $type = \PDO::PARAM_STR)
    {
        $this->statement->bindValue(':' . $param, $value, $type);
        return $this;
    }

    public function execute()
    {
        return $this->statement->execute();
    }

    public function resultSet()
    {
        $this->execute();
        return $this->statement->fetchAll();
    }

    public function single()
    {
        $this->execute();
        return $this->statement->fetch();
    }

    public function rowCount()
    {
        return $this->statement->rowCount();
    }

    public function lastInsertId()
    {
        return $this->connection->lastInsertId();
    }

    public function beginTransaction()
    {
        return $this->connection->beginTransaction();
    }

    public function commit()
    {
        return $this->connection->commit();
    }

    public function rollback()
    {
        return $this->connection->rollBack();
    }
}

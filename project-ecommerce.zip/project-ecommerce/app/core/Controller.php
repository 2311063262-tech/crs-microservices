<?php

namespace App\Core;

class Controller
{
    protected $view;
    protected $modelPath = 'App\\Models\\';

    public function __construct()
    {
        $this->view = new View();
    }

    public function model($name)
    {
        $modelName = $this->modelPath . ucfirst($name) . 'Model';
        
        if (class_exists($modelName)) {
            return new $modelName();
        }

        throw new \Exception("Model {$name} not found");
    }

    public function view($name, $data = [])
    {
        return $this->view->render($name, $data);
    }

    public function redirect($path)
    {
        header("Location: {$path}");
        exit;
    }

    public function json($data, $statusCode = 200)
    {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    public function error($message, $statusCode = 400)
    {
        $this->json(['error' => $message], $statusCode);
    }

    public function isAjax()
    {
        return $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest' ?? false;
    }

    public function getPostData()
    {
        return $_POST ?? [];
    }

    public function getRequestData()
    {
        $input = file_get_contents('php://input');
        return json_decode($input, true) ?? [];
    }
}

class View
{
    private $viewPath = __DIR__ . '/../views/';

    public function render($name, $data = [])
    {
        $viewFile = $this->viewPath . str_replace('.', '/', $name) . '.php';

        if (!file_exists($viewFile)) {
            throw new \Exception("View {$name} not found");
        }

        extract($data);
        ob_start();
        include $viewFile;
        return ob_get_clean();
    }
}

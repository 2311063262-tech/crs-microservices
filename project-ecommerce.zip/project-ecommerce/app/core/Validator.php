<?php

namespace App\Core;

class Validator
{
    private $errors = [];
    private $data = [];

    public function __construct($data)
    {
        $this->data = $data;
    }

    public function required($field, $message = null)
    {
        if (empty($this->data[$field])) {
            $this->addError($field, $message ?? "{$field} is required");
        }
        return $this;
    }

    public function email($field, $message = null)
    {
        if (!empty($this->data[$field]) && !filter_var($this->data[$field], FILTER_VALIDATE_EMAIL)) {
            $this->addError($field, $message ?? "{$field} must be a valid email");
        }
        return $this;
    }

    public function min($field, $length, $message = null)
    {
        if (!empty($this->data[$field]) && strlen($this->data[$field]) < $length) {
            $this->addError($field, $message ?? "{$field} must be at least {$length} characters");
        }
        return $this;
    }

    public function max($field, $length, $message = null)
    {
        if (!empty($this->data[$field]) && strlen($this->data[$field]) > $length) {
            $this->addError($field, $message ?? "{$field} must not exceed {$length} characters");
        }
        return $this;
    }

    public function numeric($field, $message = null)
    {
        if (!empty($this->data[$field]) && !is_numeric($this->data[$field])) {
            $this->addError($field, $message ?? "{$field} must be numeric");
        }
        return $this;
    }

    public function integer($field, $message = null)
    {
        if (!empty($this->data[$field]) && !filter_var($this->data[$field], FILTER_VALIDATE_INT)) {
            $this->addError($field, $message ?? "{$field} must be an integer");
        }
        return $this;
    }

    public function regex($field, $pattern, $message = null)
    {
        if (!empty($this->data[$field]) && !preg_match($pattern, $this->data[$field])) {
            $this->addError($field, $message ?? "{$field} format is invalid");
        }
        return $this;
    }

    public function unique($field, $table, $message = null)
    {
        if (!empty($this->data[$field])) {
            $db = new Database();
            $db->query("SELECT COUNT(*) as count FROM {$table} WHERE {$field} = :{$field}");
            $db->bind($field, $this->data[$field]);
            $result = $db->single();

            if ($result['count'] > 0) {
                $this->addError($field, $message ?? "{$field} already exists");
            }
        }
        return $this;
    }

    public function match($field, $otherField, $message = null)
    {
        if ($this->data[$field] !== ($this->data[$otherField] ?? null)) {
            $this->addError($field, $message ?? "{$field} does not match {$otherField}");
        }
        return $this;
    }

    public function url($field, $message = null)
    {
        if (!empty($this->data[$field]) && !filter_var($this->data[$field], FILTER_VALIDATE_URL)) {
            $this->addError($field, $message ?? "{$field} must be a valid URL");
        }
        return $this;
    }

    public function phone($field, $message = null)
    {
        if (!empty($this->data[$field]) && !preg_match('/^[0-9\-\+\s\(\)]{9,}$/', $this->data[$field])) {
            $this->addError($field, $message ?? "{$field} must be a valid phone number");
        }
        return $this;
    }

    private function addError($field, $message)
    {
        $this->errors[$field][] = $message;
    }

    public function passes()
    {
        return empty($this->errors);
    }

    public function fails()
    {
        return !empty($this->errors);
    }

    public function errors()
    {
        return $this->errors;
    }

    public function getError($field)
    {
        return $this->errors[$field][0] ?? null;
    }

    public function getErrors($field)
    {
        return $this->errors[$field] ?? [];
    }
}

<?php

namespace App\Core;

class Model
{
    protected $db;
    protected $table;
    protected $fillable = [];
    protected $hidden = [];

    public function __construct()
    {
        $this->db = new Database();
    }

    public function all()
    {
        $sql = "SELECT * FROM {$this->table}";
        $this->db->query($sql);
        return $this->db->resultSet();
    }

    public function find($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = :id LIMIT 1";
        $this->db->query($sql)->bind('id', $id);
        return $this->db->single();
    }

    public function where($column, $operator, $value = null)
    {
        if (is_null($value)) {
            $value = $operator;
            $operator = '=';
        }

        $sql = "SELECT * FROM {$this->table} WHERE {$column} {$operator} :{$column}";
        $this->db->query($sql)->bind($column, $value);
        return $this->db->resultSet();
    }

    public function insert($data)
    {
        $columns = implode(', ', array_keys($data));
        $values = ':' . implode(', :', array_keys($data));

        $sql = "INSERT INTO {$this->table} ({$columns}) VALUES ({$values})";
        $this->db->query($sql);

        foreach ($data as $key => $value) {
            $this->db->bind($key, $value);
        }

        if ($this->db->execute()) {
            return $this->db->lastInsertId();
        }

        return false;
    }

    public function update($id, $data)
    {
        $sql = "UPDATE {$this->table} SET ";
        $fields = [];

        foreach (array_keys($data) as $key) {
            $fields[] = "{$key} = :{$key}";
        }

        $sql .= implode(', ', $fields) . " WHERE id = :id";

        $this->db->query($sql);
        $this->db->bind('id', $id);

        foreach ($data as $key => $value) {
            $this->db->bind($key, $value);
        }

        return $this->db->execute();
    }

    public function delete($id)
    {
        $sql = "DELETE FROM {$this->table} WHERE id = :id";
        $this->db->query($sql)->bind('id', $id);
        return $this->db->execute();
    }

    public function count()
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table}";
        $this->db->query($sql);
        $result = $this->db->single();
        return $result['count'] ?? 0;
    }

    public function paginate($page = 1, $perPage = 15)
    {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT * FROM {$this->table} LIMIT {$perPage} OFFSET {$offset}";
        $this->db->query($sql);
        return $this->db->resultSet();
    }
}

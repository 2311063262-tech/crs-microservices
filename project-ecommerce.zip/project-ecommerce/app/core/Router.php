<?php

namespace App\Core;

class Router
{
    private $routes = [];
    private $currentRoute;

    public function get($path, $callback)
    {
        return $this->route('GET', $path, $callback);
    }

    public function post($path, $callback)
    {
        return $this->route('POST', $path, $callback);
    }

    public function put($path, $callback)
    {
        return $this->route('PUT', $path, $callback);
    }

    public function delete($path, $callback)
    {
        return $this->route('DELETE', $path, $callback);
    }

    public function patch($path, $callback)
    {
        return $this->route('PATCH', $path, $callback);
    }

    private function route($method, $path, $callback)
    {
        $this->routes[$method][$path] = $callback;
        $this->currentRoute = ['method' => $method, 'path' => $path];
        return $this;
    }

    public function middleware($middlewares)
    {
        if (!is_array($middlewares)) {
            $middlewares = [$middlewares];
        }

        if (isset($this->currentRoute)) {
            $route = &$this->routes[$this->currentRoute['method']][$this->currentRoute['path']];
            $route = ['callback' => $route, 'middleware' => $middlewares];
        }

        return $this;
    }

    public function dispatch()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // Remove base path
        $basePath = '/project-ecommerce/public';
        if (strpos($uri, $basePath) === 0) {
            $uri = substr($uri, strlen($basePath));
        }
        $uri = preg_replace('#^/index\.php#', '', $uri);
        if (empty($uri)) {
            $uri = '/';
        }

        // Try to match route
        if ($this->matchRoute($method, $uri)) {
            return;
        }

        // Handle 404
        http_response_code(404);
        echo "404 - Page not found";
    }

    private function matchRoute($method, $uri)
    {
        if (!isset($this->routes[$method])) {
            return false;
        }

        foreach ($this->routes[$method] as $path => $callback) {
            if ($this->pathMatches($path, $uri)) {
                $params = $this->extractParams($path, $uri);

                // Handle middleware
                if (is_array($callback) && isset($callback['middleware'])) {
                    $middlewares = $callback['middleware'];
                    foreach ($middlewares as $middleware) {
                        $this->executeMiddleware($middleware);
                    }
                    $callback = $callback['callback'];
                }

                // Execute callback
                $this->executeCallback($callback, $params);
                return true;
            }
        }

        return false;
    }

    private function pathMatches($pattern, $uri)
    {
        $pattern = preg_replace('#\{([a-zA-Z_][a-zA-Z0-9_]*)\}#', '(?P<$1>[^/]+)', $pattern);
        $pattern = '#^' . $pattern . '$#';

        return preg_match($pattern, $uri) === 1;
    }

    private function extractParams($pattern, $uri)
    {
        $pattern = preg_replace('#\{([a-zA-Z_][a-zA-Z0-9_]*)\}#', '(?P<$1>[^/]+)', $pattern);
        $pattern = '#^' . $pattern . '$#';

        preg_match($pattern, $uri, $matches);
        
        $params = [];
        foreach ($matches as $key => $value) {
            if (!is_numeric($key)) {
                $params[$key] = $value;
            }
        }

        return $params;
    }

    private function executeCallback($callback, $params = [])
    {
        $result = null;

        if (is_string($callback)) {
            [$controller, $method] = explode('@', $callback);
            $controllerClass = 'App\\Controllers\\' . $controller;

            if (!class_exists($controllerClass)) {
                throw new \Exception("Controller {$controller} not found");
            }

            $controllerInstance = new $controllerClass();
            $result = call_user_func_array([$controllerInstance, $method], array_values($params));
        } else {
            $result = call_user_func_array($callback, array_values($params));
        }

        // Render controller output when it returns a view string.
        if (is_string($result) || is_numeric($result) || $result instanceof \Stringable) {
            echo (string) $result;
        }
    }

    private function executeMiddleware($middleware)
    {
        if (is_string($middleware)) {
            $middlewareClass = 'App\\Middleware\\' . $middleware;

            if (!class_exists($middlewareClass)) {
                throw new \Exception("Middleware {$middleware} not found");
            }

            $middlewareInstance = new $middlewareClass();
            $middlewareInstance->handle();
        } else {
            call_user_func($middleware);
        }
    }
}
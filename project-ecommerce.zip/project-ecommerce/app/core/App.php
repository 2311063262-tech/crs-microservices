<?php

namespace App\Core;

class App
{
    private static $instance;
    private $config = [];
    private $router;
    private $session;

    private function __construct()
    {
        $this->loadConfig();
        $this->router = new Router();
        $this->session = new Session();
    }

    public static function getInstance()
    {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function loadConfig()
    {
        // Load .env file
        $envPath = __DIR__ . '/../../.env';
        if (file_exists($envPath)) {
            $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                if (strpos($line, '#') === 0 || strpos($line, '=') === false) {
                    continue;
                }
                [$key, $value] = explode('=', $line, 2);
                $_ENV[trim($key)] = trim($value);
            }
        }

        $this->config = [
            'app_name' => $_ENV['APP_NAME'] ?? 'Bedroom Decor eCommerce',
            'app_url' => $_ENV['APP_URL'] ?? 'http://localhost/project-ecommerce',
            'app_env' => $_ENV['APP_ENV'] ?? 'development',
            'app_debug' => $_ENV['APP_DEBUG'] ?? false,
        ];
    }

    public function get($key, $default = null)
    {
        return $this->config[$key] ?? $default;
    }

    public function getRouter()
    {
        return $this->router;
    }

    public function getSession()
    {
        return $this->session;
    }

    public function run()
    {
        $this->registerRoutes();
        $this->router->dispatch();
    }

    private function registerRoutes()
    {
        // Frontend Routes
        $this->router->get('/', 'HomeController@index');
        $this->router->get('/about', 'HomeController@about');
        $this->router->get('/contact', 'HomeController@contact');
        $this->router->get('/products', 'ProductController@index');
        $this->router->get('/product/{id}', 'ProductController@show');
        $this->router->get('/cart', 'CartController@index');
        $this->router->post('/cart/add', 'CartController@add');
        $this->router->post('/cart/remove', 'CartController@remove');
        $this->router->get('/checkout', 'CheckoutController@index')->middleware('AuthMiddleware');
        $this->router->post('/checkout', 'CheckoutController@store')->middleware('AuthMiddleware');
        $this->router->get('/payment-methods', 'PaymentController@selectMethod')->middleware('AuthMiddleware');
        $this->router->post('/payment/process', 'PaymentController@process')->middleware('AuthMiddleware');
        $this->router->get('/payment-callback/vnpay', 'PaymentCallbackController@vnpayCallback');
        $this->router->post('/payment-callback/momo', 'PaymentCallbackController@momoCallback');
        $this->router->get('/payment-result', 'PaymentController@result');
        
        $this->router->get('/wishlist', 'WishlistController@index');
        $this->router->post('/wishlist/add', 'WishlistController@add');
        $this->router->post('/wishlist/remove', 'WishlistController@remove');

        $this->router->post('/review/add', 'ReviewController@store')->middleware('AuthMiddleware');
        
        $this->router->get('/login', 'UserController@loginForm');
        $this->router->post('/login', 'UserController@login');
        $this->router->get('/register', 'UserController@registerForm');
        $this->router->post('/register', 'UserController@register');
        $this->router->get('/logout', 'UserController@logout')->middleware('AuthMiddleware');
        $this->router->get('/profile', 'UserController@profile')->middleware('AuthMiddleware');
        $this->router->post('/profile/update', 'UserController@updateProfile')->middleware('AuthMiddleware');
        
        // Admin Routes
        $this->router->get('/admin', 'AdminController@dashboard')->middleware('AdminMiddleware');
        $this->router->get('/admin/products', 'AdminController@products')->middleware('AdminMiddleware');
        $this->router->post('/admin/products/create', 'AdminController@createProduct')->middleware('AdminMiddleware');
        $this->router->post('/admin/products/update', 'AdminController@updateProduct')->middleware('AdminMiddleware');
        $this->router->post('/admin/products/delete', 'AdminController@deleteProduct')->middleware('AdminMiddleware');
        
        $this->router->get('/admin/orders', 'OrderController@index')->middleware('AdminMiddleware');
        $this->router->get('/admin/orders/{id}', 'OrderController@show')->middleware('AdminMiddleware');
        
        $this->router->get('/admin/payments', 'PaymentController@adminIndex')->middleware('AdminMiddleware');
        $this->router->get('/admin/vouchers', 'VoucherController@index')->middleware('AdminMiddleware');
        $this->router->get('/admin/reviews', 'ReviewController@index')->middleware('AdminMiddleware');
        $this->router->get('/admin/customers', 'UserController@customers')->middleware('AdminMiddleware');
        $this->router->post('/admin/customers/toggle-status', 'UserController@toggleCustomerStatus')->middleware('AdminMiddleware');
        $this->router->post('/admin/orders/update-status', 'OrderController@updateStatus')->middleware('AdminMiddleware');
        $this->router->get('/admin/reports', 'AdminController@reports')->middleware('AdminMiddleware');
    }
}

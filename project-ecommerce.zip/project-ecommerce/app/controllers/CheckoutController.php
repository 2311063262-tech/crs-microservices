<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Core\Validator;

class CheckoutController extends Controller
{
    private $session;

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
    }

    public function index()
    {
        $user = $this->session->getUser();
        $cart = $this->session->getCart();

        if (empty($cart)) {
            $this->redirect('/project-ecommerce/public/cart');
        }

        $productModel = $this->model('Product');
        $shippingModel = $this->model('Shipping');

        $cartItems = [];
        $total = 0;

        foreach ($cart as $productId => $item) {
            $product = $productModel->find($productId);
            if ($product) {
                $item['product'] = $product;
                $cartItems[] = $item;
                $total += $item['price'] * $item['quantity'];
            }
        }

        $shippingMethods = $shippingModel->getActive();

        $data = [
            'user' => $user,
            'cart_items' => $cartItems,
            'total' => $total,
            'shipping_methods' => $shippingMethods,
            'page_title' => 'Checkout'
        ];

        return $this->view('frontend.checkout', $data);
    }

    public function store()
    {
        $user = $this->session->getUser();
        $cart = $this->session->getCart();

        if (empty($cart)) {
            return $this->error('Cart is empty', 400);
        }

        $validator = new Validator($_POST);
        $validator->required('full_name');
        $validator->required('phone')->phone('phone');
        $validator->required('address');
        $validator->required('payment_method');

        if ($validator->fails()) {
            return $this->json(['errors' => $validator->errors()], 422);
        }

        $orderModel = $this->model('Order');
        $orderDetailModel = $this->model('OrderDetail');
        $productModel = $this->model('Product');

        // Calculate total
        $total = 0;
        foreach ($cart as $productId => $item) {
            $total += $item['price'] * $item['quantity'];
        }

        // Add shipping fee
        $shippingFee = $_POST['shipping_fee'] ?? 0;
        $total += floatval($shippingFee);

        // Apply voucher if exists
        $discount = 0;
        if (!empty($_POST['voucher_code'])) {
            $voucherModel = $this->model('Voucher');
            $voucher = $voucherModel->isValid($_POST['voucher_code']);
            if ($voucher) {
                $discount = ($total * $voucher['discount_percent']) / 100;
                $total -= $discount;
            }
        }

        // Create order
        $orderId = $orderModel->insert([
            'user_id' => $user['id'],
            'full_name' => $_POST['full_name'],
            'email' => $user['email'],
            'phone' => $_POST['phone'],
            'address' => $_POST['address'],
            'shipping_method' => $_POST['shipping_method'] ?? '',
            'payment_method' => $_POST['payment_method'],
            'total_amount' => $total,
            'shipping_fee' => $shippingFee,
            'discount_amount' => $discount,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ]);

        if (!$orderId) {
            return $this->error('Failed to create order', 500);
        }

        // Create order details
        foreach ($cart as $productId => $item) {
            $product = $productModel->find($productId);
            $orderDetailModel->insert([
                'order_id' => $orderId,
                'product_id' => $productId,
                'product_name' => $product['name'],
                'price' => $item['price'],
                'quantity' => $item['quantity'],
                'subtotal' => $item['price'] * $item['quantity']
            ]);
        }

        // Save order to session
        $this->session->set('current_order_id', $orderId);
        $this->session->set('payment_method', $_POST['payment_method']);

        // Clear cart
        $this->session->clearCart();

        // Redirect to payment
        return $this->json([
            'success' => true,
            'redirect_url' => '/project-ecommerce/public/payment-methods'
        ]);
    }
}

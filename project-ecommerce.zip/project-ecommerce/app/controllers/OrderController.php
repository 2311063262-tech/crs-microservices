<?php

namespace App\Controllers;

use App\Core\Controller;

class OrderController extends Controller
{
    private $allowedStatuses = ['pending', 'confirmed', 'shipped', 'completed', 'cancelled'];

    public function index()
    {
        $orderModel = $this->model('Order');
        $orders = $orderModel->all();

        return $this->view('admin.orders', [
            'orders' => $orders,
            'page_title' => 'Orders Management'
        ]);
    }

    public function show($id)
    {
        $orderModel = $this->model('Order');
        $orderDetailModel = $this->model('OrderDetail');
        $orderStatusModel = $this->model('OrderStatusHistory');

        $order = $orderModel->find($id);

        if (!$order) {
            http_response_code(404);
            return $this->json(['error' => 'Order not found'], 404);
        }

        $order['details'] = $orderDetailModel->getByOrderId($id);
        $order['status_history'] = $orderStatusModel->getByOrderId($id);

        return $this->json($order);
    }

    public function updateStatus()
    {
        $orderId = $_POST['order_id'] ?? null;
        $status = $_POST['status'] ?? null;
        $note = trim($_POST['note'] ?? '');

        if (!$orderId || !$status) {
            return $this->json(['error' => 'Thiếu dữ liệu cập nhật trạng thái'], 400);
        }

        if (!in_array($status, $this->allowedStatuses, true)) {
            return $this->json(['error' => 'Trạng thái không hợp lệ'], 422);
        }

        $orderModel = $this->model('Order');
        $statusHistoryModel = $this->model('OrderStatusHistory');

        $order = $orderModel->find($orderId);
        if (!$order) {
            return $this->json(['error' => 'Không tìm thấy đơn hàng'], 404);
        }

        $orderModel->update($orderId, ['status' => $status]);
        $statusHistoryModel->insert([
            'order_id' => $orderId,
            'status' => $status,
            'note' => $note !== '' ? $note : 'Cập nhật trạng thái từ trang quản trị',
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return $this->json([
            'success' => true,
            'message' => 'Cập nhật trạng thái thành công',
            'status' => $status
        ]);
    }
}

<?php

namespace App\Controllers;

use App\Core\Controller;

class VoucherController extends Controller
{
    public function index()
    {
        $voucherModel = $this->model('Voucher');
        $vouchers = $voucherModel->all();

        return $this->view('admin.vouchers', [
            'vouchers' => $vouchers,
            'page_title' => 'Vouchers Management'
        ]);
    }

    public function create()
    {
        $voucherModel = $this->model('Voucher');

        $voucherModel->insert([
            'code' => $_POST['code'],
            'discount_percent' => $_POST['discount_percent'],
            'max_usage' => $_POST['max_usage'],
            'used_count' => 0,
            'expire_date' => $_POST['expire_date'],
            'is_active' => $_POST['is_active'] ?? 1,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return $this->json(['success' => true, 'message' => 'Voucher created']);
    }
}

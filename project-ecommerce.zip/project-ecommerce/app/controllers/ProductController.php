<?php

namespace App\Controllers;

use App\Core\Controller;

class ProductController extends Controller
{
    public function index()
    {
        $productModel = $this->model('Product');
        $categoryModel = $this->model('Category');

        $categoryId = $_GET['category'] ?? null;
        $searchQuery = $_GET['search'] ?? null;
        $page = $_GET['page'] ?? 1;
        $perPage = 12;

        $products = [];

        if ($searchQuery) {
            $products = $productModel->search($searchQuery);
        } elseif ($categoryId) {
            $products = $productModel->getByCategory($categoryId);
        } else {
            $products = $productModel->getActive();
        }

        $categories = $categoryModel->getActive();

        $data = [
            'products' => $products,
            'categories' => $categories,
            'current_category' => $categoryId,
            'search_query' => $searchQuery,
            'page_title' => 'Products - Bedroom Decor'
        ];

        return $this->view('frontend.product-list', $data);
    }

    public function show($id)
    {
        $productModel = $this->model('Product');
        $imageModel = $this->model('ProductImage');
        $variantModel = $this->model('ProductVariant');
        $reviewModel = $this->model('Review');

        $product = $productModel->find($id);

        if (!$product) {
            http_response_code(404);
            return $this->view('404');
        }

        $product['images'] = $imageModel->getByProductId($id);
        $product['variants'] = $variantModel->getByProductId($id);
        $product['reviews'] = $reviewModel->getByProductId($id);
        $product['average_rating'] = $reviewModel->getAverageRating($id);

        $data = [
            'product' => $product,
            'page_title' => $product['name'] . ' - Bedroom Decor'
        ];

        return $this->view('frontend.product-detail', $data);
    }
}

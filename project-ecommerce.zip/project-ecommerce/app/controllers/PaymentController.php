<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;

class PaymentController extends Controller
{
    private $session;

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
    }

    public function selectMethod()
    {
        $paymentConfig = require __DIR__ . '/../../config/payment.php';

        $paymentMethods = [
            $paymentConfig['cod'],
            $paymentConfig['bank_transfer'],
            $paymentConfig['momo'],
            $paymentConfig['vnpay']
        ];

        return $this->view('frontend.payment-methods', [
            'payment_methods' => $paymentMethods,
            'page_title' => 'Select Payment Method'
        ]);
    }

    public function process()
    {
        $orderId = $this->session->get('current_order_id');
        $paymentMethod = $_POST['payment_method'] ?? null;

        if (!$orderId || !$paymentMethod) {
            return $this->error('Invalid payment request', 400);
        }

        $orderModel = $this->model('Order');
        $paymentModel = $this->model('Payment');
        $paymentLogModel = $this->model('PaymentLog');

        $order = $orderModel->find($orderId);

        if (!$order) {
            return $this->error('Order not found', 404);
        }

        // Create payment record
        $paymentId = $paymentModel->insert([
            'order_id' => $orderId,
            'user_id' => $order['user_id'],
            'payment_method' => $paymentMethod,
            'amount' => $order['total_amount'],
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s')
        ]);

        if (!$paymentId) {
            return $this->error('Failed to create payment', 500);
        }

        // Get payment service
        $paymentClass = '\\App\\Services\\Payment\\' . ucfirst($paymentMethod) . 'Payment';

        if (!class_exists($paymentClass)) {
            return $this->error('Payment method not supported', 400);
        }

        $paymentService = new $paymentClass();

        $paymentData = [
            'order_id' => $orderId,
            'payment_id' => $paymentId,
            'amount' => $order['total_amount'],
            'order_info' => 'Order #' . $orderId
        ];

        $result = $paymentService->process($paymentData);

        // Log payment attempt
        $paymentLogModel->log($paymentId, $paymentMethod, 'process', $paymentData, $result);

        if (!$result['success']) {
            // Update payment status to failed
            $paymentModel->update($paymentId, ['status' => 'failed']);
            return $this->json($result, 400);
        }

        if (isset($result['redirect_url'])) {
            $this->session->delete('current_order_id');
            return $this->json(['success' => true, 'redirect_url' => $result['redirect_url']]);
        }

        return $this->json($result);
    }

    public function result()
    {
        $status = $_GET['status'] ?? 'unknown';

        return $this->view('frontend.payment-result', [
            'status' => $status,
            'page_title' => 'Payment Result'
        ]);
    }

    public function adminIndex()
    {
        $paymentModel = $this->model('Payment');
        $payments = $paymentModel->all();

        return $this->view('admin.payments', [
            'payments' => $payments,
            'page_title' => 'Payment Management'
        ]);
    }
}

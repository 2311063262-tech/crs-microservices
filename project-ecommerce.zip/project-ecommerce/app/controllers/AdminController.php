<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;

class AdminController extends Controller
{
    private $session;

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
    }

    public function dashboard()
    {
        $productModel = $this->model('Product');
        $orderModel = $this->model('Order');
        $userModel = $this->model('User');
        $paymentModel = $this->model('Payment');

        $totalProducts = $productModel->count();
        $totalOrders = $orderModel->count();
        $totalCustomers = count($userModel->getCustomers());
        $totalRevenue = 0;

        $payments = $paymentModel->getCompleted();
        foreach ($payments as $payment) {
            $totalRevenue += $payment['amount'];
        }

        $recentOrders = $orderModel->paginate(1, 5);

        return $this->view('admin.dashboard', [
            'total_products' => $totalProducts,
            'total_orders' => $totalOrders,
            'total_customers' => $totalCustomers,
            'total_revenue' => $totalRevenue,
            'recent_orders' => $recentOrders,
            'page_title' => 'Admin Dashboard'
        ]);
    }

    public function products()
    {
        $productModel = $this->model('Product');
        $products = $productModel->all();

        return $this->view('admin.products', [
            'products' => $products,
            'page_title' => 'Products Management'
        ]);
    }

    public function createProduct()
    {
        $productModel = $this->model('Product');
        $categoryModel = $this->model('Category');

        $productId = $productModel->insert([
            'category_id' => $_POST['category_id'],
            'name' => $_POST['name'],
            'description' => $_POST['description'],
            'price' => $_POST['price'],
            'stock' => $_POST['stock'],
            'is_featured' => $_POST['is_featured'] ?? 0,
            'is_active' => $_POST['is_active'] ?? 1,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return $this->json([
            'success' => true,
            'message' => 'Product created successfully',
            'product_id' => $productId
        ]);
    }

    public function updateProduct()
    {
        $productId = $_POST['product_id'] ?? null;
        $productModel = $this->model('Product');

        if (!$productId) {
            return $this->json(['error' => 'Product ID is required'], 400);
        }

        $productModel->update($productId, [
            'category_id' => $_POST['category_id'],
            'name' => $_POST['name'],
            'description' => $_POST['description'],
            'price' => $_POST['price'],
            'stock' => $_POST['stock'],
            'is_featured' => $_POST['is_featured'] ?? 0,
            'is_active' => $_POST['is_active'] ?? 1
        ]);

        return $this->json(['success' => true, 'message' => 'Product updated successfully']);
    }

    public function deleteProduct()
    {
        $productId = $_POST['product_id'] ?? null;
        $productModel = $this->model('Product');

        if (!$productId) {
            return $this->json(['error' => 'Product ID is required'], 400);
        }

        $productModel->delete($productId);

        return $this->json(['success' => true, 'message' => 'Product deleted successfully']);
    }

    public function reports()
    {
        $orderModel = $this->model('Order');

        $fromDate = $_GET['from_date'] ?? date('Y-m-01');
        $toDate = $_GET['to_date'] ?? date('Y-m-d');

        $summary = $orderModel->getSalesSummary($fromDate, $toDate);
        $topProducts = $orderModel->getTopSellingProducts($fromDate, $toDate, 10);
        $dailyRevenue = $orderModel->getDailyRevenue($fromDate, $toDate);
        $statusStats = $orderModel->getStatusStats($fromDate, $toDate);

        return $this->view('admin.reports', [
            'summary' => $summary,
            'top_products' => $topProducts,
            'daily_revenue' => $dailyRevenue,
            'status_stats' => $statusStats,
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'page_title' => 'Thống kê doanh số'
        ]);
    }
}

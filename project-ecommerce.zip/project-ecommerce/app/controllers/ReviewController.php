<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;

class ReviewController extends Controller
{
    private $session;

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
    }

    public function store()
    {
        $user = $this->session->getUser();
        $reviewModel = $this->model('Review');

        $reviewModel->insert([
            'product_id' => $_POST['product_id'],
            'user_id' => $user['id'],
            'rating' => $_POST['rating'],
            'comment' => $_POST['comment'],
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return $this->json(['success' => true, 'message' => 'Review added successfully']);
    }

    public function index()
    {
        $reviewModel = $this->model('Review');
        $reviews = $reviewModel->all();

        return $this->view('admin.reviews', [
            'reviews' => $reviews,
            'page_title' => 'Reviews Management'
        ]);
    }
}

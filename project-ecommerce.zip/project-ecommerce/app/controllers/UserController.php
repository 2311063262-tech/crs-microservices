<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Core\Validator;

class UserController extends Controller
{
    private $session;

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
    }

    public function loginForm()
    {
        if ($this->session->isLoggedIn()) {
            $this->redirect('/project-ecommerce/public/');
        }

        return $this->view('frontend.login', ['page_title' => 'Login']);
    }

    public function login()
    {
        $validator = new Validator($_POST);
        $validator->required('email')->email('email');
        $validator->required('password');

        if ($validator->fails()) {
            return $this->view('frontend.login', [
                'errors' => $validator->errors(),
                'page_title' => 'Login'
            ]);
        }

        $userModel = $this->model('User');
        $results = $userModel->findByEmail($_POST['email']);

        if ($results && verifyPassword($_POST['password'], $results[0]['password'])) {
            $this->session->setUser($results[0]);
            $this->session->flash('success', 'Welcome back!');
            $this->redirect('/project-ecommerce/public/');
        }

        $this->session->flash('error', 'Invalid email or password');
        $this->redirect('/project-ecommerce/public/login');
    }

    public function registerForm()
    {
        if ($this->session->isLoggedIn()) {
            $this->redirect('/project-ecommerce/public/');
        }

        return $this->view('frontend.register', ['page_title' => 'Register']);
    }

    public function register()
    {
        $validator = new Validator($_POST);
        $validator->required('name')->required('email')->email('email');
        $validator->required('password')->min('password', 8);
        $validator->required('confirm_password')->match('confirm_password', 'password');

        if ($validator->fails()) {
            return $this->view('frontend.register', [
                'errors' => $validator->errors(),
                'page_title' => 'Register'
            ]);
        }

        $userModel = $this->model('User');
        $existing = $userModel->findByEmail($_POST['email']);

        if ($existing) {
            $this->session->flash('error', 'Email already exists');
            $this->redirect('/project-ecommerce/public/register');
        }

        $userId = $userModel->insert([
            'name' => $_POST['name'],
            'email' => $_POST['email'],
            'password' => hashPassword($_POST['password']),
            'phone' => $_POST['phone'] ?? '',
            'address' => $_POST['address'] ?? '',
            'role' => 'customer',
            'created_at' => date('Y-m-d H:i:s')
        ]);

        if ($userId) {
            $user = $userModel->find($userId);
            $this->session->setUser($user);
            $this->session->flash('success', 'Registration successful!');
            $this->redirect('/project-ecommerce/public/');
        }

        $this->session->flash('error', 'Registration failed');
        $this->redirect('/project-ecommerce/public/register');
    }

    public function logout()
    {
        $this->session->logout();
        $this->session->flash('success', 'You have been logged out');
        $this->redirect('/project-ecommerce/public/');
    }

    public function profile()
    {
        $user = $this->session->getUser();
        $orderModel = $this->model('Order');
        $orders = $orderModel->getByUserId($user['id']);

        return $this->view('frontend.profile', [
            'user' => $user,
            'orders' => $orders,
            'page_title' => 'My Profile'
        ]);
    }

    public function updateProfile()
    {
        $user = $this->session->getUser();

        $validator = new Validator($_POST);
        $validator->required('name');

        if ($validator->fails()) {
            return $this->json(['error' => $validator->errors()], 422);
        }

        $userModel = $this->model('User');
        $userModel->update($user['id'], [
            'name' => $_POST['name'],
            'phone' => $_POST['phone'] ?? '',
            'address' => $_POST['address'] ?? ''
        ]);

        $updatedUser = $userModel->find($user['id']);
        $this->session->setUser($updatedUser);

        return $this->json(['success' => true, 'message' => 'Profile updated successfully']);
    }

    public function customers()
    {
        $userModel = $this->model('User');
        $customers = $userModel->getCustomers();

        return $this->view('admin.customers', [
            'customers' => $customers,
            'page_title' => 'Manage Customers'
        ]);
    }

    public function toggleCustomerStatus()
    {
        $customerId = $_POST['customer_id'] ?? null;
        $isActive = isset($_POST['is_active']) ? (int) $_POST['is_active'] : null;

        if (!$customerId || !in_array($isActive, [0, 1], true)) {
            return $this->json(['error' => 'Dữ liệu không hợp lệ'], 422);
        }

        $userModel = $this->model('User');
        $customer = $userModel->find($customerId);

        if (!$customer || ($customer['role'] ?? '') !== 'customer') {
            return $this->json(['error' => 'Không tìm thấy khách hàng'], 404);
        }

        $userModel->update($customerId, ['is_active' => $isActive]);

        return $this->json([
            'success' => true,
            'message' => $isActive ? 'Đã mở khóa tài khoản' : 'Đã khóa tài khoản',
            'is_active' => $isActive
        ]);
    }
}

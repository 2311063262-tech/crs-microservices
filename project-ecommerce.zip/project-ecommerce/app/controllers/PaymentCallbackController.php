<?php

namespace App\Controllers;

use App\Core\Controller;

class PaymentCallbackController extends Controller
{
    public function vnpayCallback()
    {
        $paymentLogModel = $this->model('PaymentLog');
        $paymentModel = $this->model('Payment');
        $orderModel = $this->model('Order');
        $orderStatusModel = $this->model('OrderStatusHistory');

        // Log callback
        $paymentLogModel->log(0, 'vnpay', 'callback', $_GET, $_GET);

        // Create payment service
        $paymentService = new \App\Services\Payment\VnpayPayment();

        // Verify callback
        if (!$paymentService->verifyCallback($_GET)) {
            writeLog('VNPay callback verification failed', 'payment.log');
            $this->json(['error' => 'Invalid callback'], 401);
        }

        $orderId = $_GET['vnp_TxnRef'] ?? null;
        $resultCode = $_GET['vnp_ResponseCode'] ?? null;

        if (!$orderId) {
            return $this->json(['error' => 'Order not found'], 404);
        }

        // Extract real order ID (remove timestamp)
        $orderId = substr($orderId, 5, -10);

        $order = $orderModel->find($orderId);

        if (!$order) {
            return $this->json(['error' => 'Order not found'], 404);
        }

        // Update payment status
        $payment = $paymentModel->getByOrderId($orderId);
        $payment = $payment[0] ?? null;

        if ($payment) {
            if ($resultCode == '00') {
                $paymentModel->update($payment['id'], ['status' => 'completed']);
                $orderModel->update($orderId, ['status' => 'confirmed']);

                // Add status history
                $orderStatusModel->insert([
                    'order_id' => $orderId,
                    'status' => 'confirmed',
                    'note' => 'Payment confirmed via VNPay',
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                writeLog('VNPay payment successful for order #' . $orderId, 'payment.log');
            } else {
                $paymentModel->update($payment['id'], ['status' => 'failed']);
                $orderModel->update($orderId, ['status' => 'cancelled']);
                writeLog('VNPay payment failed for order #' . $orderId . ' - Code: ' . $resultCode, 'payment.log');
            }
        }

        // Redirect to result page
        header('Location: /project-ecommerce/public/payment-result?status=' . ($resultCode == '00' ? 'success' : 'failure'));
        exit;
    }

    public function momoCallback()
    {
        $paymentLogModel = $this->model('PaymentLog');
        $paymentModel = $this->model('Payment');
        $orderModel = $this->model('Order');
        $orderStatusModel = $this->model('OrderStatusHistory');

        // Get raw POST data
        $postData = json_decode(file_get_contents('php://input'), true);

        // Log callback
        $paymentLogModel->log(0, 'momo', 'callback', $postData, $postData);

        // Create payment service
        $paymentService = new \App\Services\Payment\MomoPayment();

        // Verify callback
        if (!$paymentService->verifyCallback($postData)) {
            writeLog('MoMo callback verification failed', 'payment.log');
            return $this->json(['error' => 'Invalid callback'], 401);
        }

        $orderId = $postData['orderId'] ?? null;
        $resultCode = $postData['resultCode'] ?? null;

        if (!$orderId) {
            return $this->json(['error' => 'Order not found'], 404);
        }

        $order = $orderModel->find($orderId);

        if (!$order) {
            return $this->json(['error' => 'Order not found'], 404);
        }

        // Update payment status
        $payment = $paymentModel->getByOrderId($orderId);
        $payment = $payment[0] ?? null;

        if ($payment) {
            if ($resultCode == 0) {
                $paymentModel->update($payment['id'], ['status' => 'completed']);
                $orderModel->update($orderId, ['status' => 'confirmed']);

                // Add status history
                $orderStatusModel->insert([
                    'order_id' => $orderId,
                    'status' => 'confirmed',
                    'note' => 'Payment confirmed via MoMo',
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                writeLog('MoMo payment successful for order #' . $orderId, 'payment.log');
            } else {
                $paymentModel->update($payment['id'], ['status' => 'failed']);
                $orderModel->update($orderId, ['status' => 'cancelled']);
                writeLog('MoMo payment failed for order #' . $orderId . ' - Code: ' . $resultCode, 'payment.log');
            }
        }

        return $this->json(['success' => true]);
    }
}

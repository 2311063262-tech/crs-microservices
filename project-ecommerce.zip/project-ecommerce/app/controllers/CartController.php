<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;

class CartController extends Controller
{
    private $session;

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
    }

    public function index()
    {
        $cart = $this->session->getCart();
        $productModel = $this->model('Product');

        $cartItems = [];
        $total = 0;

        foreach ($cart as $productId => $item) {
            $product = $productModel->find($productId);
            if ($product) {
                $item['product'] = $product;
                $cartItems[] = $item;
                $total += $item['price'] * $item['quantity'];
            }
        }

        $data = [
            'cart_items' => $cartItems,
            'total' => $total,
            'page_title' => 'Shopping Cart'
        ];

        return $this->view('frontend.cart', $data);
    }

    public function add()
    {
        if ($this->isAjax()) {
            $postData = $this->getRequestData();
            $productId = $postData['product_id'] ?? null;
            $quantity = $postData['quantity'] ?? 1;

            $productModel = $this->model('Product');
            $product = $productModel->find($productId);

            if (!$product) {
                return $this->error('Product not found', 404);
            }

            $cart = $this->session->getCart();
            
            if (isset($cart[$productId])) {
                $cart[$productId]['quantity'] += $quantity;
            } else {
                $cart[$productId] = [
                    'product_id' => $productId,
                    'name' => $product['name'],
                    'price' => $product['price'],
                    'quantity' => $quantity
                ];
            }

            $this->session->setCart($cart);

            return $this->json([
                'success' => true,
                'message' => 'Product added to cart',
                'cart_count' => count($cart)
            ]);
        }

        return $this->error('Invalid request');
    }

    public function remove()
    {
        if ($this->isAjax()) {
            $postData = $this->getRequestData();
            $productId = $postData['product_id'] ?? null;

            $cart = $this->session->getCart();
            unset($cart[$productId]);
            $this->session->setCart($cart);

            return $this->json([
                'success' => true,
                'message' => 'Product removed from cart',
                'cart_count' => count($cart)
            ]);
        }

        return $this->error('Invalid request');
    }
}

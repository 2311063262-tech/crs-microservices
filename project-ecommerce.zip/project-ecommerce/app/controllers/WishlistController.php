<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;

class WishlistController extends Controller
{
    private $session;

    public function __construct()
    {
        parent::__construct();
        $this->session = new Session();
    }

    public function index()
    {
        $user = $this->session->getUser();
        $wishlistModel = $this->model('Wishlist');
        $productModel = $this->model('Product');

        $wishlistItems = $wishlistModel->getByUserId($user['id']);

        $products = [];
        foreach ($wishlistItems as $item) {
            $product = $productModel->find($item['product_id']);
            if ($product) {
                $products[] = $product;
            }
        }

        return $this->view('frontend.wishlist', [
            'products' => $products,
            'page_title' => 'My Wishlist'
        ]);
    }

    public function add()
    {
        $user = $this->session->getUser();
        $wishlistModel = $this->model('Wishlist');

        $productId = $_POST['product_id'] ?? null;

        if (!$wishlistModel->isInWishlist($user['id'], $productId)) {
            $wishlistModel->insert([
                'user_id' => $user['id'],
                'product_id' => $productId,
                'created_at' => date('Y-m-d H:i:s')
            ]);
        }

        return $this->json(['success' => true, 'message' => 'Added to wishlist']);
    }

    public function remove()
    {
        $user = $this->session->getUser();
        $wishlistModel = $this->model('Wishlist');
        $productId = $_POST['product_id'] ?? null;

        $results = $wishlistModel->where('user_id', '=', $user['id']);
        
        foreach ($results as $item) {
            if ($item['product_id'] == $productId) {
                $wishlistModel->delete($item['id']);
                break;
            }
        }

        return $this->json(['success' => true, 'message' => 'Removed from wishlist']);
    }
}

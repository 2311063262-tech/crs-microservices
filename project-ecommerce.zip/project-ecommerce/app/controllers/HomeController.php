<?php

namespace App\Controllers;

use App\Core\Controller;

class HomeController extends Controller
{
    public function index()
    {
        $productModel = $this->model('Product');
        $categoryModel = $this->model('Category');

        $categories = $categoryModel->getActive();
        $featuredProducts = $productModel->getFeatured();
        $allProducts = $productModel->getActive();

        $data = [
            'categories' => $categories,
            'featured_products' => $featuredProducts,
            'all_products' => $allProducts,
            'page_title' => 'Bedroom Decor - Home'
        ];

        return $this->view('frontend.home', $data);
    }

    public function about()
    {
        return $this->view('frontend.about', [
            'page_title' => 'Về chúng tôi - Bedroom Decor'
        ]);
    }

    public function contact()
    {
        return $this->view('frontend.contact', [
            'page_title' => 'Liên hệ - Bedroom Decor'
        ]);
    }
}

<?php

namespace App\Middleware;

use App\Core\Session;

class AuthMiddleware
{
    public function handle()
    {
        $session = new Session();
        
        if (!$session->isLoggedIn()) {
            header('Location: /project-ecommerce/public/login');
            exit;
        }
    }
}

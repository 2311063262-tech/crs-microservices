<?php

namespace App\Middleware;

use App\Core\Session;

class CsrfMiddleware
{
    public function handle()
    {
        $session = new Session();

        // Generate CSRF token if not exists
        if (!$session->has('csrf_token')) {
            $session->set('csrf_token', bin2hex(random_bytes(32)));
        }

        // Verify CSRF token for POST/PUT/DELETE requests
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;

            if (!$token || $token !== $session->get('csrf_token')) {
                http_response_code(419);
                echo json_encode(['error' => 'CSRF token mismatch']);
                exit;
            }
        }
    }

    public static function token()
    {
        $session = new Session();
        return $session->get('csrf_token', '');
    }
}

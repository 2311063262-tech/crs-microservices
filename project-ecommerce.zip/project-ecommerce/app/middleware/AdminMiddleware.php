<?php

namespace App\Middleware;

use App\Core\Session;

class AdminMiddleware
{
    public function handle()
    {
        $session = new Session();
        $user = $session->getUser();

        if (!$user || $user['role'] !== 'admin') {
            http_response_code(403);
            echo "Access Denied";
            exit;
        }
    }
}

<?php

// Format tiền tệ VNĐ
function formatVND($amount)
{
    return number_format($amount, 0, '.', ',') . ' ₫';
}

// Format ngày tháng
function formatDate($date, $format = 'd/m/Y H:i')
{
    return date($format, strtotime($date));
}

// Tạo slug từ chuỗi
function createSlug($string)
{
    $string = mb_strtolower($string, 'UTF-8');
    $string = preg_replace('/[^a-z0-9\s-]/', '', $string);
    $string = preg_replace('/\s+/', '-', $string);
    $string = preg_replace('/-+/', '-', $string);
    return trim($string, '-');
}

// Xóa HTML tags
function sanitizeHtml($html)
{
    return htmlspecialchars($html, ENT_QUOTES, 'UTF-8');
}

// Cắt chuỗi
function truncate($string, $length = 100)
{
    if (strlen($string) > $length) {
        return substr($string, 0, $length) . '...';
    }
    return $string;
}

// Upload hình ảnh
function uploadImage($file, $uploadPath = 'public/uploads/images/')
{
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }

    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB

    if (!in_array($file['type'], $allowedTypes) || $file['size'] > $maxSize) {
        return false;
    }

    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0755, true);
    }

    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('img_') . '.' . $extension;
    $filepath = $uploadPath . $filename;

    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $filename;
    }

    return false;
}

// Kiểm tra email hợp lệ
function isValidEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Kiểm tra password mạnh
function isStrongPassword($password)
{
    return strlen($password) >= 8 && 
           preg_match('/[A-Z]/', $password) &&
           preg_match('/[a-z]/', $password) &&
           preg_match('/[0-9]/', $password);
}

// Hash password
function hashPassword($password)
{
    return password_hash($password, PASSWORD_BCRYPT);
}

// Verify password
function verifyPassword($password, $hash)
{
    return password_verify($password, $hash);
}

// Logging
function writeLog($message, $file = 'app.log')
{
    $logPath = __DIR__ . '/../../storage/logs/' . $file;
    
    if (!is_dir(dirname($logPath))) {
        mkdir(dirname($logPath), 0755, true);
    }

    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[{$timestamp}] {$message}\n";
    
    file_put_contents($logPath, $logMessage, FILE_APPEND);
}

// Get app config
function config($key, $default = null)
{
    static $config = [];

    if (empty($config)) {
        $config = require __DIR__ . '/../../config/database.php';
    }

    return $config[$key] ?? $default;
}

// Convert đơn vị tính kích thước file
function formatBytes($bytes, $precision = 2)
{
    $units = ['B', 'KB', 'MB', 'GB'];
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}

// Kiểm tra xem một giá trị có phải là số dương không
function isPositiveNumber($value)
{
    return is_numeric($value) && $value > 0;
}

// Tính phần trăm
function calculatePercentage($value, $total)
{
    return $total > 0 ? ($value / $total) * 100 : 0;
}

// Redirect
function redirect($url)
{
    header("Location: {$url}");
    exit;
}

// Session helpers
function getSession($key, $default = null)
{
    return $_SESSION[$key] ?? $default;
}

function setSession($key, $value)
{
    $_SESSION[$key] = $value;
}

function hasSession($key)
{
    return isset($_SESSION[$key]);
}

function deleteSession($key)
{
    unset($_SESSION[$key]);
}

<?php

declare(strict_types=1);

$basePath = dirname(__DIR__, 2);
$envPath = $basePath . '/.env';

if (file_exists($envPath)) {
    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if ($line === '' || strpos(ltrim($line), '#') === 0 || strpos($line, '=') === false) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($value);
    }
}

$config = require $basePath . '/config/database.php';
$dsn = sprintf(
    'mysql:host=%s;port=%s;dbname=%s;charset=%s',
    $config['host'],
    $config['port'],
    $config['database'],
    $config['charset']
);

try {
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Throwable $e) {
    fwrite(STDERR, "Cannot connect DB: " . $e->getMessage() . PHP_EOL);
    exit(1);
}

$requiredTables = ['categories', 'products', 'users'];
foreach ($requiredTables as $table) {
    $stmt = $pdo->prepare('SHOW TABLES LIKE :table_name');
    $stmt->execute(['table_name' => $table]);
    if (!$stmt->fetchColumn()) {
        fwrite(STDERR, "Missing table: {$table}. Please import database/schema.sql first." . PHP_EOL);
        exit(1);
    }
}

$categories = [
    ['name' => 'Anh sang', 'description' => 'Den ngu, den tuong va den ban trang tri.'],
    ['name' => 'Giuong va Nem', 'description' => 'Khung giuong, nem va phu kien giac ngu.'],
    ['name' => 'Rem va Tham', 'description' => 'Rem cua va tham phong ngu hien dai.'],
    ['name' => 'Trang tri tuong', 'description' => 'Tranh, guong va vat dung tao diem nhan.'],
    ['name' => 'Goi va Chan', 'description' => 'Bo goi, vo goi va chan mem cao cap.'],
];

$categoryIds = [];
$categorySelect = $pdo->prepare('SELECT id FROM categories WHERE name = :name LIMIT 1');
$categoryInsert = $pdo->prepare('INSERT INTO categories (name, description, is_active) VALUES (:name, :description, 1)');

foreach ($categories as $category) {
    $categorySelect->execute(['name' => $category['name']]);
    $existingId = $categorySelect->fetchColumn();

    if ($existingId) {
        $categoryIds[$category['name']] = (int) $existingId;
        continue;
    }

    $categoryInsert->execute([
        'name' => $category['name'],
        'description' => $category['description'],
    ]);

    $categoryIds[$category['name']] = (int) $pdo->lastInsertId();
}

$products = [
    [
        'category_name' => 'Anh sang',
        'name' => 'Den Ngu Bong May',
        'description' => 'Den ngu anh sang am, phu hop phong cach hien dai va toi gian.',
        'price' => 549000,
        'stock' => 24,
        'image' => 'lamp-cloud.svg',
        'is_featured' => 1,
    ],
    [
        'category_name' => 'Giuong va Nem',
        'name' => 'Bo Ga Goi Cotton Pastel',
        'description' => 'Bo ga goi cotton mem, thoang khi va de phoi mau voi noi that.',
        'price' => 890000,
        'stock' => 18,
        'image' => 'cotton-pastel.svg',
        'is_featured' => 1,
    ],
    [
        'category_name' => 'Rem va Tham',
        'name' => 'Rem Cua Chong Nang Linen',
        'description' => 'Rem linen hai lop, giam sang tot va tao cam giac rieng tu.',
        'price' => 1290000,
        'stock' => 12,
        'image' => 'curtain-linen.svg',
        'is_featured' => 0,
    ],
    [
        'category_name' => 'Trang tri tuong',
        'name' => 'Bo 3 Tranh Canvas Bac Au',
        'description' => 'Bo tranh tone trung tinh de trang tri dau giuong sang trong.',
        'price' => 720000,
        'stock' => 10,
        'image' => 'canvas-set.svg',
        'is_featured' => 1,
    ],
    [
        'category_name' => 'Goi va Chan',
        'name' => 'Chan Len Nhe 4 Mua',
        'description' => 'Chat lieu mem min, giu am nhe va de giat may.',
        'price' => 460000,
        'stock' => 30,
        'image' => 'blanket-soft.svg',
        'is_featured' => 0,
    ],
    [
        'category_name' => 'Anh sang',
        'name' => 'Den Tuong Kim Loai Co Dien',
        'description' => 'Mau den dong, phu hop phong ngu phong cach vintage.',
        'price' => 680000,
        'stock' => 16,
        'image' => 'wall-lamp.svg',
        'is_featured' => 0,
    ],
    [
        'category_name' => 'Rem va Tham',
        'name' => 'Tham Long Ngan Mieu Ta',
        'description' => 'Tham mem cho khu vuc giuong, tao diem nhan am cung.',
        'price' => 510000,
        'stock' => 22,
        'image' => 'rug-soft.svg',
        'is_featured' => 1,
    ],
    [
        'category_name' => 'Trang tri tuong',
        'name' => 'Guong Tron Vien Go',
        'description' => 'Guong tron phong cach toi gian, de lap dat.',
        'price' => 390000,
        'stock' => 20,
        'image' => 'mirror-round.svg',
        'is_featured' => 0,
    ],
];

$productSelect = $pdo->prepare('SELECT id FROM products WHERE name = :name LIMIT 1');
$productInsert = $pdo->prepare(
    'INSERT INTO products (category_id, name, description, price, stock, image, is_featured, is_active) '
    . 'VALUES (:category_id, :name, :description, :price, :stock, :image, :is_featured, 1)'
);

$insertedProducts = 0;
foreach ($products as $product) {
    $productSelect->execute(['name' => $product['name']]);
    if ($productSelect->fetchColumn()) {
        continue;
    }

    $productInsert->execute([
        'category_id' => $categoryIds[$product['category_name']] ?? null,
        'name' => $product['name'],
        'description' => $product['description'],
        'price' => $product['price'],
        'stock' => $product['stock'],
        'image' => $product['image'],
        'is_featured' => $product['is_featured'],
    ]);

    $insertedProducts++;
}

$adminEmail = 'admin@bedroomdecor.vn';
$adminSelect = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
$adminSelect->execute(['email' => $adminEmail]);
if (!$adminSelect->fetchColumn()) {
    $adminInsert = $pdo->prepare(
        'INSERT INTO users (name, email, password, role, is_active) VALUES (:name, :email, :password, :role, 1)'
    );

    $adminInsert->execute([
        'name' => 'Admin',
        'email' => $adminEmail,
        'password' => password_hash('admin123', PASSWORD_BCRYPT),
        'role' => 'admin',
    ]);
}

$imageDir = $basePath . '/public/assets/images';
if (!is_dir($imageDir)) {
    mkdir($imageDir, 0755, true);
}

$svgFiles = [
    'lamp-cloud.svg' => ['#d9ecff', '#7ab6ea', 'Den Ngu'],
    'cotton-pastel.svg' => ['#ffe8f1', '#f39cbc', 'Ga Goi'],
    'curtain-linen.svg' => ['#f0efe8', '#cbc7ad', 'Rem Linen'],
    'canvas-set.svg' => ['#ececff', '#9ea0de', 'Tranh Canvas'],
    'blanket-soft.svg' => ['#fff2de', '#dfb886', 'Chan Mem'],
    'wall-lamp.svg' => ['#f7e8dc', '#c98852', 'Den Tuong'],
    'rug-soft.svg' => ['#e5f7f0', '#6bc39f', 'Tham'],
    'mirror-round.svg' => ['#e8f1f7', '#8aa7bd', 'Guong'],
];

foreach ($svgFiles as $fileName => $meta) {
    $filePath = $imageDir . '/' . $fileName;
    if (file_exists($filePath)) {
        continue;
    }

    [$bg, $accent, $label] = $meta;
    $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800" role="img" aria-label="{$label}">
  <rect width="1200" height="800" fill="{$bg}"/>
  <rect x="170" y="250" width="860" height="330" rx="30" fill="#ffffff"/>
  <circle cx="300" cy="360" r="90" fill="{$accent}"/>
  <rect x="450" y="320" width="420" height="80" rx="12" fill="{$accent}" opacity="0.8"/>
  <rect x="450" y="440" width="300" height="40" rx="10" fill="#8b96a0" opacity="0.5"/>
  <text x="600" y="680" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="52" fill="#3f4a54">{$label}</text>
</svg>
SVG;

    file_put_contents($filePath, $svg);
}

$totalCategories = (int) $pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();
$totalProducts = (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();

echo "Seed complete" . PHP_EOL;
echo "Categories: {$totalCategories}" . PHP_EOL;
echo "Products: {$totalProducts}" . PHP_EOL;
echo "New products inserted: {$insertedProducts}" . PHP_EOL;
echo "Admin login: {$adminEmail} / admin123" . PHP_EOL;

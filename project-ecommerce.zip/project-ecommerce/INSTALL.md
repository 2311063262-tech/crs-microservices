# Hướng dẫn cài đặt Bedroom Decor eCommerce

## Bước 1: Yêu cầu hệ thống

- PHP >= 7.4
- MySQL 5.7 hoặc cao hơn
- Apache với mod_rewrite
- Composer (optional)

## Bước 2: Tạo CSDL

1. Mở phpMyAdmin hoặc MySQL command line
2. Tạo database:
```sql
CREATE DATABASE ecommerce_bedroom_decor CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

3. Import schema SQL:
```bash
mysql -u root -p ecommerce_bedroom_decor < database/schema.sql
```

Hoặc sao chép nội dung từ `database/schema.sql` và chạy trong phpMyAdmin

## Bước 3: Cấu hình .env

1. Sao chép file `.env.example` thành `.env`
2. Chỉnh sửa các giá trị:

```env
# Database
DB_HOST=localhost
DB_PORT=3306
DB_NAME=ecommerce_bedroom_decor
DB_USER=root
DB_PASS=

# App
APP_NAME=Bedroom Decor eCommerce
APP_URL=http://localhost/project-ecommerce/public
APP_ENV=development
APP_DEBUG=true

# Payment Gateway - VNPay (nếu sử dụng)
VNPAY_MERCHANT_ID=
VNPAY_HASH_SECRET=

# Payment Gateway - MoMo (nếu sử dụng)
MOMO_PARTNER_CODE=
MOMO_ACCESS_KEY=
MOMO_SECRET_KEY=
```

## Bước 4: Cài đặt Dependencies (Optional)

Nếu bạn muốn sử dụng Composer:

```bash
composer install
```

## Bước 5: Cấu hình Apache

### Nếu dùng XAMPP/WAMP:

1. Đảm bảo mod_rewrite đã được enable
2. File `.htaccess` đã được tạo trong `public/` directory
3. Truy cập qua: `http://localhost/project-ecommerce/public`

### Nếu dùng PHP Built-in Server:

```bash
cd project-ecommerce
php -S localhost:8000 -t public
```

Sau đó truy cập: `http://localhost:8000`

## Bước 6: Kiểm tra Cài đặt

1. Truy cập trang chủ: `http://localhost/project-ecommerce/public/`
2. Kiểm tra xem tất cả chức năng có hoạt động không
3. Kiểm tra logs trong `storage/logs/`

## Bước 7: Tài khoản Admin Mặc định

Sau khi import schema.sql, tài khoản admin sẽ được tạo:
- Email: `admin@bedroomdecor.vn`
- Password: `admin123` (hash đã được cấu hình)

Truy cập admin panel: `http://localhost/project-ecommerce/public/admin`

**Lưu ý**: Nên đổi password ngay sau lần đăng nhập đầu tiên

## Bước 8: Cấu hình Thanh toán (Optional)

### VNPay
1. Đăng ký tại [VNPay Sandbox](https://sandbox.vnpayment.vn)
2. Lấy Merchant ID và Hash Secret
3. Thêm vào `.env`:
```
VNPAY_MERCHANT_ID=your_merchant_id
VNPAY_HASH_SECRET=your_hash_secret
```

### MoMo
1. Đăng ký tại [MoMo Developers](https://momo.vn/developers)
2. Lấy Partner Code, Access Key, Secret Key
3. Thêm vào `.env`:
```
MOMO_PARTNER_CODE=your_partner_code
MOMO_ACCESS_KEY=your_access_key
MOMO_SECRET_KEY=your_secret_key
```

## Troubleshooting

### 404 Not Found
- Kiểm tra `.htaccess` trong `public/` directory
- Đảm bảo mod_rewrite được enable
- Kiểm tra RewriteBase trong `.htaccess`

### Database Connection Error
- Kiểm tra thông tin database trong `.env`
- Đảm bảo MySQL đang chạy
- Kiểm tra user và password

### Permission Denied
- Kiểm tra quyền truy cập của thư mục `storage/logs/`
- Cho quyền ghi: `chmod -R 755 storage/`

### 500 Internal Server Error
- Kiểm tra `storage/logs/errors.log`
- Bật `APP_DEBUG=true` trong `.env`

## Cấu trúc thư mục quan trọng

```
public/                  # Entry point của ứng dụng
├── index.php            # File chính
├── .htaccess            # Rewrite rules
└── assets/              # CSS, JS, Images
    ├── css/
    ├── js/
    └── images/

app/
├── core/                # Core classes
├── controllers/         # Controllers
├── models/              # Models
├── views/               # Templates
├── middleware/          # Middleware
├── services/            # Services
└── helpers/             # Helper functions

storage/logs/            # Log files
config/                  # Configuration files
database/                # Database migrations & seeds
```

## Bảo mật

1. **Đổi password admin** sau lần đăng nhập đầu tiên
2. **Cập nhật .env** không được commit lên repository
3. **Enable HTTPS** trên production
4. **Cấu hình CORS** nếu cần
5. **Cập nhật PHP** lên phiên bản mới nhất
6. **Disable debug mode** trên production: `APP_DEBUG=false`

## Thêm Sản phẩm

1. Đăng nhập Admin Panel
2. Vào **Quản lý sản phẩm**
3. Thêm sản phẩm mới
4. Điền thông tin chi tiết
5. Upload hình ảnh
6. Lưu

## Tích hợp Email (Optional)

Để gửi email xác nhận đơn hàng, cấu hình SMTP:

```env
MAIL_HOST=smtp.mailtrap.io
MAIL_PORT=465
MAIL_USERNAME=your_username
MAIL_PASSWORD=your_password
```

## Tiếp theo

Sau khi cài đặt thành công, bạn có thể:
- Thêm sản phẩm vào website
- Cấu hình phương thức thanh toán
- Tùy chỉnh giao diện
- Mở rộng chức năng

## Hỗ trợ

Nếu có vấn đề, hãy:
1. Kiểm tra logs trong `storage/logs/`
2. Đọc lại hướng dẫn này
3. Liên hệ admin

---

**Chúc mừng! Bạn đã cài đặt thành công!** 🎉

# Bedroom Decor eCommerce

Một website thương mại điện tử bán đồ trang trí phòng ngủ được xây dựng bằng PHP thuần (vanilla PHP) với kiến trúc MVC.

## Tính năng chính

### Frontend
- 🏠 Trang chủ với sản phẩm nổi bật
- 📦 Danh sách sản phẩm với tìm kiếm và lọc theo danh mục
- 🔍 Xem chi tiết sản phẩm, hình ảnh, biến thể (size/màu), đánh giá
- 🛒 Giỏ hàng với quản lý số lượng sản phẩm
- ❤️ Danh sách yêu thích
- 💳 Quy trình thanh toán đầy đủ
- 💰 4 phương thức thanh toán:
  - **COD**: Thanh toán khi nhận hàng
  - **Bank Transfer**: Chuyển khoản ngân hàng
  - **MoMo**: Ví MoMo (tích hợp API)
  - **VNPay**: Cổng thanh toán VNPay (tích hợp API)
- 📝 Đánh giá sản phẩm (rating, bình luận)
- 👤 Quản lý tài khoản người dùng
- 🎟️ Áp dụng mã giảm giá
- 🚚 Tính phí vận chuyển tự động
- 📋 Xem lịch sử đơn hàng

### Admin Panel
- 📊 Dashboard với thống kê
- 📦 Quản lý sản phẩm (tạo, sửa, xóa)
- 📋 Quản lý đơn hàng
- 💳 Quản lý giao dịch thanh toán
- 🎟️ Quản lý mã giảm giá
- ⭐ Quản lý đánh giá sản phẩm
- 👥 Quản lý khách hàng

## Cấu trúc thư mục

```
project-ecommerce/
├── app/
│   ├── controllers/          # Các controller xử lý logic
│   ├── middleware/           # Middleware bảo vệ route
│   ├── models/               # Các model tương tác CSDL
│   ├── services/
│   │   └── payment/          # Các service thanh toán
│   ├── views/
│   │   ├── frontend/         # View frontend
│   │   └── admin/            # View admin
│   ├── helpers/              # Các hàm tiện ích
│   └── core/                 # Core classes (Database, Model, Controller, Router, etc.)
├── config/                   # Tệp cấu hình
├── database/                 # Migration và seeder
├── public/                   # Thư mục public (entry point)
│   ├── index.php             # Entry point
│   └── assets/
│       ├── css/              # CSS files
│       ├── js/               # JavaScript files
│       └── images/           # Hình ảnh
├── storage/                  # Lưu trữ logs
├── resources/                # Tài nguyên (ngôn ngữ, etc.)
├── .env                      # Biến môi trường
├── .env.example              # Mẫu biến môi trường
├── composer.json             # PHP dependencies
└── README.md                 # Tài liệu này
```

## Yêu cầu hệ thống

- PHP >= 7.4
- MySQL 5.7 hoặc cao hơn
- Apache (với mod_rewrite)
- Composer (optional)

## Cài đặt

### 1. Clone/Copy dự án
```bash
cd c:\xampp\htdocs\BTL
# Dự án đã được tạo tại thư mục project-ecommerce
```

### 2. Cấu hình .env
```bash
# Sao chép .env.example thành .env
cp .env.example .env

# Chỉnh sửa .env với thông tin CSDL của bạn
# Thêm API keys cho VNPay và MoMo (nếu cần)
```

### 3. Tạo CSDL
```sql
CREATE DATABASE ecommerce_bedroom_decor CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 4. Import cấu trúc CSDL
Tạo các bảng sau trong CSDL:

```sql
-- Users
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    role ENUM('admin', 'customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2),
    stock INT DEFAULT 0,
    image VARCHAR(255),
    is_featured TINYINT DEFAULT 0,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Thêm các bảng khác tương tự...
```

### 5. Chạy ứng dụng
```bash
# Bằng PHP built-in server
php -S localhost:8000 -t public

# Hoặc bằng Apache
# Truy cập: http://localhost/project-ecommerce/public
```

## Cấu hình Apache

Đảm bảo file `.htaccess` đã được cấu hình chính xác trong thư mục `public/`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /project-ecommerce/public/
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ index.php?$1 [L,QSA]
</IfModule>
```

## Tài khoản Admin Mặc định

Sau khi cài đặt, hãy tạo tài khoản admin thông qua giao diện hoặc SQL:

```sql
INSERT INTO users (name, email, password, role) 
VALUES ('Admin', 'admin@example.com', PASSWORD('admin123'), 'admin');
```

## Cấu hình Thanh toán

### VNPay
1. Đăng ký tài khoản tại https://sandbox.vnpayment.vn
2. Lấy Merchant ID và Hash Secret
3. Thêm vào `.env`:
```
VNPAY_MERCHANT_ID=your_merchant_id
VNPAY_HASH_SECRET=your_hash_secret
```

### MoMo
1. Đăng ký tại https://momo.vn/developers
2. Lấy Partner Code, Access Key, Secret Key
3. Thêm vào `.env`:
```
MOMO_PARTNER_CODE=your_partner_code
MOMO_ACCESS_KEY=your_access_key
MOMO_SECRET_KEY=your_secret_key
```

## Các Routes Chính

### Frontend
- `GET /` - Trang chủ
- `GET /products` - Danh sách sản phẩm
- `GET /product/:id` - Chi tiết sản phẩm
- `GET /cart` - Giỏ hàng
- `POST /cart/add` - Thêm vào giỏ
- `GET /checkout` - Thanh toán (cần đăng nhập)
- `GET /login` - Đăng nhập
- `GET /register` - Đăng ký

### Admin (cần đăng nhập và role admin)
- `GET /admin` - Dashboard
- `GET /admin/products` - Quản lý sản phẩm
- `GET /admin/orders` - Quản lý đơn hàng
- `GET /admin/payments` - Quản lý thanh toán

## Bảo mật

- ✅ Hash password với bcrypt
- ✅ CSRF protection middleware
- ✅ Validation input
- ✅ SQL injection protection (prepared statements)
- ✅ Session management

## Logging

Logs được lưu tại `storage/logs/`:
- `app.log` - Application errors
- `payment.log` - Payment transactions
- `errors.log` - PHP errors

## Helpers

Các hàm tiện ích có sẵn:
- `formatVND($amount)` - Format tiền tệ VNĐ
- `formatDate($date)` - Format ngày tháng
- `hashPassword($password)` - Mã hóa password
- `verifyPassword($password, $hash)` - Kiểm tra password
- `uploadImage($file)` - Upload hình ảnh
- `writeLog($message)` - Ghi log

## Đóng góp

Nếu bạn muốn đóng góp cho dự án, vui lòng tạo pull request hoặc báo cáo issues.

## Giấy phép

MIT License - xem file LICENSE để biết chi tiết.

## Liên hệ

- Email: info@bedroomdecor.vn
- Hotline: 0123 456 789

---

**Chúc mừng! Bạn đã cài đặt thành công Bedroom Decor eCommerce!** 🎉

<?php

return [
    'cod' => [
        'name' => 'Cash on Delivery',
        'code' => 'cod',
        'enabled' => true,
        'description' => 'Payment upon delivery'
    ],
    
    'bank_transfer' => [
        'name' => 'Bank Transfer',
        'code' => 'bank_transfer',
        'enabled' => true,
        'description' => 'Direct bank transfer',
        'bank_accounts' => [
            [
                'bank_name' => 'Vietcombank',
                'account_holder' => 'Your Company Name',
                'account_number' => '1234567890',
                'branch' => 'Ha Noi Branch'
            ]
        ]
    ],
    
    'momo' => [
        'name' => 'MoMo Wallet',
        'code' => 'momo',
        'enabled' => true,
        'partner_code' => $_ENV['MOMO_PARTNER_CODE'] ?? '',
        'access_key' => $_ENV['MOMO_ACCESS_KEY'] ?? '',
        'secret_key' => $_ENV['MOMO_SECRET_KEY'] ?? '',
        'api_url' => $_ENV['MOMO_API_URL'] ?? 'https://test-payment.momo.vn/v2/gateway/api/create',
        'ipn_url' => $_ENV['APP_URL'] . '/payment-callback/momo',
        'redirect_url' => $_ENV['APP_URL'] . '/payment-result'
    ],
    
    'vnpay' => [
        'name' => 'VNPay Payment',
        'code' => 'vnpay',
        'enabled' => true,
        'merchant_id' => $_ENV['VNPAY_MERCHANT_ID'] ?? '',
        'hash_secret' => $_ENV['VNPAY_HASH_SECRET'] ?? '',
        'api_url' => $_ENV['VNPAY_API_URL'] ?? 'https://sandbox.vnpayment.vn/paymentweb/api/transaction',
        'payment_url' => 'https://sandbox.vnpayment.vn/paygate',
        'ipn_url' => $_ENV['APP_URL'] . '/payment-callback/vnpay',
        'return_url' => $_ENV['APP_URL'] . '/payment-result'
    ]
];

# Quick Start Guide - Bedroom Decor eCommerce

## Bắt đầu nhanh trong 5 phút

### 1. Tạo CSDL
```sql
CREATE DATABASE ecommerce_bedroom_decor CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. Import Schema
```bash
mysql -u root ecommerce_bedroom_decor < database/schema.sql
```

### 3. Cấu hình .env
```bash
cp .env.example .env
# Chỉnh sửa DB_HOST, DB_USER, DB_PASS
```

### 4. Chạy ứng dụng
**Cách 1: PHP Built-in Server**
```bash
php -S localhost:8000 -t public
# Truy cập: http://localhost:8000
```

**Cách 2: Apache (XAMPP/WAMP)**
```
http://localhost/project-ecommerce/public
```

### 5. Đăng nhập Admin
- **URL**: http://localhost/project-ecommerce/public/admin
- **Email**: admin@bedroomdecor.vn
- **Password**: admin123 (hãy đổi ngay!)

## Tính năng chính

### Frontend
✅ Xem sản phẩm
✅ Giỏ hàng
✅ Thanh toán (4 phương thức: COD, Bank, MoMo, VNPay)
✅ Đăng nhập/Đăng ký
✅ Quản lý tài khoản
✅ Đánh giá sản phẩm
✅ Danh sách yêu thích

### Admin Panel
✅ Dashboard thống kê
✅ Quản lý sản phẩm
✅ Quản lý đơn hàng
✅ Quản lý thanh toán
✅ Quản lý khách hàng

## Cấu trúc MVC

```
app/
├── controllers/         # Logic xử lý
├── models/              # CSDL interaction
├── views/               # Hiển thị
├── middleware/          # Bảo vệ route
├── services/payment/    # Payment gateways
└── core/                # Core classes
```

## Mẹo

1. **Logs**: Kiểm tra `storage/logs/` nếu có lỗi
2. **Debug**: Bật `APP_DEBUG=true` trong `.env`
3. **Thêm sản phẩm**: Vào Admin > Sản phẩm > Thêm
4. **Test Payment**: COD không cần cấu hình thêm

## Vấn đề thường gặp

**404 Not Found?**
- Kiểm tra `.htaccess` được bật mod_rewrite
- Kiểm tra URL: `/project-ecommerce/public/`

**Database connection error?**
- Kiểm tra `.env` DB_* settings
- MySQL có đang chạy?

**Permission denied?**
- `chmod 755 storage/` 
- `chmod 755 public/uploads/`

## Tiếp theo

Đọc thêm:
- [INSTALL.md](INSTALL.md) - Hướng dẫn chi tiết
- [README.md](README.md) - Tài liệu đầy đủ
- [database/schema.sql](database/schema.sql) - Cấu trúc CSDL

---

**Chúc mừng! Bạn đã sẵn sàng phát triển! 🚀**

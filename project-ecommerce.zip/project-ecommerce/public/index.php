<?php

// Ép hiển thị lỗi ngay lập tức ra màn hình
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

/**
 * Entry point cho ứng dụng eCommerce
 */

// Định nghĩa base path
define('BASE_PATH', realpath(__DIR__ . '/..'));
define('APP_PATH', BASE_PATH . '/app');
define('PUBLIC_PATH', __DIR__);

// Load environment file loader
require_once BASE_PATH . '/app/core/Database.php';
require_once BASE_PATH . '/app/core/Model.php';
require_once BASE_PATH . '/app/core/Controller.php';
require_once BASE_PATH . '/app/core/Session.php';
require_once BASE_PATH . '/app/core/Validator.php';
require_once BASE_PATH . '/app/core/Router.php';
require_once BASE_PATH . '/app/core/App.php';

// Load helpers
require_once BASE_PATH . '/app/helpers/functions.php';

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $baseDir = APP_PATH . '/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Initialize and run application
try {
    $app = \App\Core\App::getInstance();
    $app->run();
} catch (Throwable $e) {
    if (ob_get_level()) {
        ob_end_clean(); // Xóa bộ đệm kẹt
    }
    echo "<h1>Lỗi ứng dụng:</h1>";
    echo "<h3>" . $e->getMessage() . "</h3>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}
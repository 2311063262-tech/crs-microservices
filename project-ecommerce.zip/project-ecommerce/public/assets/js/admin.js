// Admin JavaScript

// Open add product modal
function openAddProductModal() {
    document.getElementById('productModal').style.display = 'block';
    document.getElementById('productId').value = '';
    document.getElementById('productForm').reset();
}

// Close product modal
function closeProductModal() {
    document.getElementById('productModal').style.display = 'none';
}

// Edit product
function editProduct(productId) {
    // TODO: Fetch product data and populate form
    openAddProductModal();
}

// Delete product
function deleteProduct(productId) {
    if (confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')) {
        fetch('/project-ecommerce/public/admin/products/delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                product_id: productId
            })
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Xóa thành công!');
                    location.reload();
                }
            });
    }
}

// View order
function viewOrder(orderId) {
    fetch(`/project-ecommerce/public/admin/orders/${orderId}`)
        .then(response => response.json())
        .then(data => {
            const details = (data.details || [])
                .map(item => `- ${item.product_name} x${item.quantity}`)
                .join('\n');

            const history = (data.status_history || [])
                .map(item => `${item.created_at}: ${item.status}`)
                .join('\n');

            alert(
                `Đơn #${data.id}\n` +
                `Khách: ${data.full_name}\n` +
                `Tổng: ${data.total_amount}\n\n` +
                `Sản phẩm:\n${details || 'Chưa có'}\n\n` +
                `Lịch sử trạng thái:\n${history || 'Chưa có'}`
            );
        });
}

function updateOrderStatus(orderId) {
    const select = document.getElementById(`status-${orderId}`);
    if (!select) {
        alert('Không tìm thấy trạng thái đơn hàng để cập nhật');
        return;
    }

    const formData = new FormData();
    formData.append('order_id', orderId);
    formData.append('status', select.value);

    fetch('/project-ecommerce/public/admin/orders/update-status', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Cập nhật trạng thái thành công');
                location.reload();
                return;
            }

            alert('Lỗi: ' + (data.error || 'Không thể cập nhật trạng thái'));
        })
        .catch(() => alert('Không thể kết nối tới máy chủ'));
}

function toggleCustomerStatus(customerId, nextStatus) {
    const actionText = nextStatus === 1 ? 'mở khóa' : 'khóa';
    if (!confirm(`Bạn có chắc muốn ${actionText} tài khoản này?`)) {
        return;
    }

    const formData = new FormData();
    formData.append('customer_id', customerId);
    formData.append('is_active', nextStatus);

    fetch('/project-ecommerce/public/admin/customers/toggle-status', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message || 'Cập nhật thành công');
                location.reload();
                return;
            }

            alert('Lỗi: ' + (data.error || 'Không thể cập nhật tài khoản'));
        })
        .catch(() => alert('Không thể kết nối tới máy chủ'));
}

// Close modal
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function (event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

// Submit product form
document.addEventListener('DOMContentLoaded', function () {
    const productForm = document.getElementById('productForm');
    if (productForm) {
        productForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(this);
            const productId = document.getElementById('productId').value;
            const url = productId
                ? '/project-ecommerce/public/admin/products/update'
                : '/project-ecommerce/public/admin/products/create';

            fetch(url, {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Lưu thành công!');
                        location.reload();
                    } else {
                        alert('Lỗi: ' + (data.error || 'Lưu thất bại'));
                    }
                });
        });
    }
});

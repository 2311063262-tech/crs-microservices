// Main JavaScript

// Format VND
function formatVND(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount);
}

// Add to cart
function addToCart(productId) {
    const quantity = document.getElementById('quantity')?.value || 1;

    fetch('/project-ecommerce/public/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            product_id: productId,
            quantity: parseInt(quantity)
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Product added to cart!');
            document.getElementById('cartCount').textContent = data.cart_count;
        }
    })
    .catch(error => console.error('Error:', error));
}

// Remove from cart
function removeFromCart(productId) {
    fetch('/project-ecommerce/public/cart/remove', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            product_id: productId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    })
    .catch(error => console.error('Error:', error));
}

// Add to wishlist
function addToWishlist(productId) {
    fetch('/project-ecommerce/public/wishlist/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            product_id: productId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Added to wishlist!');
        }
    })
    .catch(error => console.error('Error:', error));
}

// Remove from wishlist
function removeFromWishlist(productId) {
    fetch('/project-ecommerce/public/wishlist/remove', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
            product_id: productId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    })
    .catch(error => console.error('Error:', error));
}

// Change main image
function changeMainImage(img) {
    const mainImage = document.querySelector('.product-images .main-image img');
    if (mainImage) {
        mainImage.src = img.src;
    }
}

// Document ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips, popovers, etc.
    console.log('Page loaded');
});
